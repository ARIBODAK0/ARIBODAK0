package com.hybridmind.app.domain.usecase

import com.hybridmind.app.domain.model.ChatSession
import com.hybridmind.app.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class CreateChatSessionUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(title: String = "New Chat"): ChatSession {
        return chatRepository.createSession(title)
    }
}

class GetChatSessionsUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(): Flow<List<ChatSession>> {
        return chatRepository.getAllSessions()
    }
}

class DeleteChatSessionUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(sessionId: String) {
        chatRepository.deleteSession(sessionId)
    }
}

class ClearAllSessionsUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke() {
        chatRepository.deleteAllSessions()
    }
}

class UpdateSessionTitleUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(sessionId: String, newTitle: String) {
        val session = chatRepository.getSession(sessionId)
        session?.let {
            chatRepository.updateSession(it.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
        }
    }
}
