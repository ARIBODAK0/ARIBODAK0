package com.hybridmind.app.domain.repository

import com.hybridmind.app.domain.model.ChatMessage
import com.hybridmind.app.domain.model.ChatSession
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for chat operations
 */
interface ChatRepository {
    
    // Session operations
    suspend fun createSession(title: String = "New Chat"): ChatSession
    suspend fun getSession(sessionId: String): ChatSession?
    suspend fun getAllSessions(): Flow<List<ChatSession>>
    suspend fun updateSession(session: ChatSession)
    suspend fun deleteSession(sessionId: String)
    suspend fun deleteAllSessions()
    
    // Message operations
    suspend fun insertMessage(message: ChatMessage)
    suspend fun insertMessages(messages: List<ChatMessage>)
    suspend fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>>
    suspend fun getMessageCountForSession(sessionId: String): Int
    suspend fun deleteMessage(messageId: String)
    suspend fun deleteMessagesForSession(sessionId: String)
    suspend fun updateMessage(message: ChatMessage)
    
    // Context management
    suspend fun getRecentMessagesForContext(sessionId: String, limit: Int = 20): List<ChatMessage>
    suspend fun getContextTokenCount(sessionId: String): Int
    suspend fun pruneOldMessages(sessionId: String, keepCount: Int = 50)
}
