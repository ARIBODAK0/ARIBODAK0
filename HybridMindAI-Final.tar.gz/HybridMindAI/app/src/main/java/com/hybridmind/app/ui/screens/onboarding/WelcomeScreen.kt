package com.hybridmind.app.ui.screens.onboarding

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun WelcomeScreen(onNavigateToModelSetup: () -> Unit) {
    var currentPage by remember { mutableIntStateOf(0) }
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(100)
        isVisible = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
    ) {
        AnimatedBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.weight(1f))

            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(animationSpec = tween(1000)) + slideInVertically { it / 2 }
            ) {
                when (currentPage) {
                    0 -> WelcomePage(onContinue = { currentPage = 1 })
                    1 -> PrivacyPage(onContinue = { currentPage = 2 })
                    2 -> LocalFirstPage(onContinue = { currentPage = 3 })
                    3 -> HybridPowerPage(onGetStarted = onNavigateToModelSetup)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            if (currentPage > 0) {
                PageIndicator(pageCount = 4, currentPage = currentPage, modifier = Modifier.padding(bottom = 32.dp))
            }
        }
    }
}

@Composable
private fun WelcomePage(onContinue: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 16.dp)) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(brush = Brush.linearGradient(colors = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary))),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.White)
        }

        Spacer(modifier = Modifier.height(32.dp))
        Text(text = "Selamat Datang di HybridMind AI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Asisten AI Privat yang Berjalan 100% di Perangkat Anda", style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(text = "Lanjutkan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PrivacyPage(onContinue: () -> Unit) {
    FeaturePage(
        icon = Icons.Default.Security,
        title = "Privasi adalah Prioritas",
        description = "Semua data dan percakapan disimpan secara lokal di perangkat Anda. Tidak ada data yang dikirim ke server eksternal.",
        onContinue = onContinue,
        iconGradient = listOf(Color(0xFF10B981), Color(0xFF059669))
    )
}

@Composable
private fun LocalFirstPage(onContinue: () -> Unit) {
    FeaturePage(
        icon = Icons.Default.Devices,
        title = "Local-First Architecture",
        description = "Model AI berjalan langsung di perangkat Anda menggunakan llama.cpp. Tidak perlu koneksi internet untuk chat biasa.",
        onContinue = onContinue,
        iconGradient = listOf(Color(0xFF8B5CF6), Color(0xFF7C3AED))
    )
}

@Composable
private fun HybridPowerPage(onGetStarted: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 16.dp)) {
        Box(
            modifier = Modifier.size(100.dp).clip(RoundedCornerShape(24.dp)).background(brush = Brush.linearGradient(colors = listOf(Color(0xFFF59E0B), Color(0xFFD97706)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Language, contentDescription = null, modifier = Modifier.size(56.dp), tint = Color.White)
        }

        Spacer(modifier = Modifier.height(32.dp))
        Text(text = "Kekuatan Hybrid", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Aktifkan Web Search untuk mendapatkan informasi real-time ketika diperlukan.", style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(48.dp))

        Button(onClick = onGetStarted, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Text(text = "Mulai", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun FeaturePage(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String, onContinue: () -> Unit, iconGradient: List<Color>) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 16.dp)) {
        Box(modifier = Modifier.size(100.dp).clip(RoundedCornerShape(24.dp)).background(brush = Brush.linearGradient(colors = iconGradient)), contentAlignment = Alignment.Center) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(56.dp), tint = Color.White)
        }

        Spacer(modifier = Modifier.height(32.dp))
        Text(text = title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = description, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(48.dp))

        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Text(text = "Lanjutkan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PageIndicator(pageCount: Int, currentPage: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(pageCount) { index ->
            val isSelected = index == currentPage
            val size by animateDpAsState(targetValue = if (isSelected) 24.dp else 8.dp, animationSpec = tween(300), label = "indicator_size")
            Box(modifier = Modifier.height(8.dp).width(size).clip(CircleShape).background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
        }
    }
}

@Composable
private fun AnimatedBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "background")
    val offset1 by infiniteTransition.animateFloat(initialValue = 0f, targetValue = 1f, animationSpec = infiniteRepeatable(animation = tween(8000), repeatMode = RepeatMode.Reverse), label = "offset1")
    val offset2 by infiniteTransition.animateFloat(initialValue = 1f, targetValue = 0f, animationSpec = infiniteRepeatable(animation = tween(10000), repeatMode = RepeatMode.Reverse), label = "offset2")

    Box(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.size(300.dp).offset(x = (offset1 * 50 - 25).dp, y = (offset1 * 100 - 50).dp).blur(100.dp).background(brush = Brush.radialGradient(colors = listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), Color.Transparent)), shape = CircleShape).align(Alignment.TopStart))
        Box(modifier = Modifier.size(250.dp).offset(x = (offset2 * -50 + 25).dp, y = (offset2 * -80 + 40).dp).blur(80.dp).background(brush = Brush.radialGradient(colors = listOf(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f), Color.Transparent)), shape = CircleShape).align(Alignment.BottomEnd))
    }
}
