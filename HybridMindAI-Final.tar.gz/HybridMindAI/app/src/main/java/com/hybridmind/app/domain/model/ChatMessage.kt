package com.hybridmind.app.domain.model

import java.util.UUID

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM
}

data class SearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    val source: String
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val searchResults: List<SearchResult>? = null,
    val error: String? = null
)
