package com.hybridmind.app.domain.repository

import com.hybridmind.app.domain.model.*
import kotlinx.coroutines.flow.StateFlow

interface LlmRepository {
    val loadingState: StateFlow<ModelLoadingState>
    val isModelLoaded: StateFlow<Boolean>
    val currentModel: StateFlow<LlmModel?>

    suspend fun loadModel(filePath: String, parameters: ModelParameters = ModelParameters()): Result<LlmModel>
    suspend fun unloadModel()
    suspend fun validateModelFile(filePath: String): Result<Boolean>

    suspend fun generateCompletion(
        prompt: String,
        systemPrompt: String? = null,
        parameters: ModelParameters? = null,
        onToken: suspend (String) -> Unit
    ): Result<String>

    suspend fun generateChatCompletion(
        messages: List<Pair<String, String>>,
        systemPrompt: String? = null,
        parameters: ModelParameters? = null,
        onToken: suspend (String) -> Unit
    ): Result<String>

    fun stopGeneration()
    fun isGenerating(): Boolean
    suspend fun getModelInfo(filePath: String): Result<LlmModel>
    suspend fun setBackend(backend: InferenceBackend)
    fun getCurrentBackend(): InferenceBackend
    fun getMemoryUsage(): Pair<Long, Long>
    suspend fun tokenize(text: String): Result<Int>
}
