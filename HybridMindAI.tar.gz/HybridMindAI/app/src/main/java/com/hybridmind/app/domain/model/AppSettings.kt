package com.hybridmind.app.domain.model

/**
 * Application settings domain model
 */
data class AppSettings(
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val personality: AIPersonality = AIPersonality.FRIENDLY,
    val backend: InferenceBackend = InferenceBackend.CPU,
    val useWebSearch: Boolean = false,
    val autoSpeak: Boolean = false,
    val saveHistory: Boolean = true,
    val contextLimit: Int = 4096,
    val autoSummarize: Boolean = true,
    val batterySaverThreshold: Int = 15,
    val language: String = "id" // Indonesian default
)

enum class AIPersonality(val displayName: String, val prompt: String) {
    FRIENDLY(
        "Ramah",
        "Anda adalah asisten AI yang ramah, hangat, dan mudah diajak berbicara. " +
        "Jawablah dengan sopan dan gunakan bahasa sehari-hari yang mudah dipahami."
    ),
    CODER(
        "Programmer",
        "Anda adalah asisten AI yang ahli dalam pemrograman. " +
        "Berikan kode yang bersih, terdokumentasi dengan baik, dan ikuti best practices. " +
        "Jelaskan konsep teknis dengan jelas dan berikan contoh kode yang relevan."
    ),
    WRITER(
        "Penulis",
        "Anda adalah asisten AI yang ahli dalam menulis dan tata bahasa. " +
        "Bantu pengguna menyusun teks yang menarik, grammatically correct, dan sesuai konteks. " +
        "Berikan saran untuk meningkatkan kualitas tulisan."
    ),
    STRICT(
        "Formal",
        "Anda adalah asisten AI yang profesional dan formal. " +
        "Berikan jawaban yang akurat, ringkas, dan langsung ke inti permasalahan. " +
        "Hindari bahasa yang terlalu santai atau tidak perlu."
    );
    
    companion object {
        fun fromDisplayName(name: String): AIPersonality {
            return entries.find { it.displayName == name } ?: FRIENDLY
        }
    }
}

const val DEFAULT_SYSTEM_PROMPT = "Anda adalah HybridMind AI, asisten AI yang membantu, jujur, dan tidak berbahaya. " +
        "Anda selalu menjawab dengan bahasa Indonesia yang baik dan benar. " +
        "Jika Anda tidak tahu jawabannya, katakan saja Anda tidak tahu."
