package com.hybridmind.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

/**
 * Receiver for monitoring battery level
 * Pauses inference when battery is low
 */
@AndroidEntryPoint
class BatteryLevelReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BATTERY_CHANGED) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val batteryPct = level * 100 / scale.toFloat()

            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL

            Timber.d("Battery level: $batteryPct%, Charging: $isCharging")

            // Notify listeners about battery state
            onBatteryStateChanged?.invoke(batteryPct, isCharging)

            // Pause inference if battery is low and not charging
            if (batteryPct < BATTERY_THRESHOLD && !isCharging) {
                onLowBattery?.invoke()
            }
        }
    }

    companion object {
        private const val BATTERY_THRESHOLD = 15f

        var onBatteryStateChanged: ((Float, Boolean) -> Unit)? = null
        var onLowBattery: (() -> Unit)? = null

        fun register(context: Context) {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            context.registerReceiver(BatteryLevelReceiver(), filter)
        }

        fun getBatteryLevel(context: Context): Float {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            return level * 100 / scale.toFloat()
        }

        fun isCharging(context: Context): Boolean {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            return status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
        }
    }
}
