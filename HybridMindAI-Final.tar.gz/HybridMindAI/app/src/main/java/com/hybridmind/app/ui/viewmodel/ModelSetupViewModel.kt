package com.hybridmind.app.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybridmind.app.domain.model.LlmModel
import com.hybridmind.app.domain.model.ModelLoadingState
import com.hybridmind.app.domain.model.ModelParameters
import com.hybridmind.app.domain.usecase.LoadModelUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ModelSetupViewModel @Inject constructor(
    private val loadModelUseCase: LoadModelUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ModelSetupUiState())
    val uiState: StateFlow<ModelSetupUiState> = _uiState.asStateFlow()

    private val _loadingState = MutableStateFlow<ModelLoadingState>(ModelLoadingState.Idle)
    val loadingState: StateFlow<ModelLoadingState> = _loadingState.asStateFlow()

    fun onFileSelected(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                _loadingState.value = ModelLoadingState.Validating

                val filePath = getPathFromUri(context, uri)
                if (filePath == null) {
                    _loadingState.value = ModelLoadingState.Error("Tidak dapat mengakses file", com.hybridmind.app.domain.model.ErrorType.FILE_NOT_FOUND)
                    return@launch
                }

                val file = File(filePath)
                if (!file.exists()) {
                    _loadingState.value = ModelLoadingState.Error("File tidak ditemukan", com.hybridmind.app.domain.model.ErrorType.FILE_NOT_FOUND)
                    return@launch
                }

                if (!file.name.endsWith(".gguf", ignoreCase = true)) {
                    _loadingState.value = ModelLoadingState.Error("File harus berformat .gguf", com.hybridmind.app.domain.model.ErrorType.UNSUPPORTED_FORMAT)
                    return@launch
                }

                _uiState.update { it.copy(selectedFile = file, isValidFile = true) }
                _loadingState.value = ModelLoadingState.Idle

            } catch (e: Exception) {
                Timber.e(e, "Error selecting file")
                _loadingState.value = ModelLoadingState.Error(e.message ?: "Error", com.hybridmind.app.domain.model.ErrorType.UNKNOWN)
            }
        }
    }

    fun loadModel() {
        val file = _uiState.value.selectedFile ?: return

        viewModelScope.launch {
            _loadingState.value = ModelLoadingState.Loading(0)

            loadModelUseCase(file.absolutePath)
                .onSuccess { model ->
                    _uiState.update { it.copy(selectedModel = model) }
                    _loadingState.value = ModelLoadingState.Success(model)
                }
                .onFailure { error ->
                    Timber.e(error, "Failed to load model")
                    _loadingState.value = ModelLoadingState.Error(error.message ?: "Gagal", com.hybridmind.app.domain.model.ErrorType.UNKNOWN)
                }
        }
    }

    private fun getPathFromUri(context: Context, uri: Uri): String? {
        return when (uri.scheme) {
            "file" -> uri.path
            "content" -> copyUriToCache(context, uri)
            else -> null
        }
    }

    private fun copyUriToCache(context: Context, uri: Uri): String? {
        return try {
            val fileName = uri.lastPathSegment ?: "model.gguf"
            val cacheDir = File(context.cacheDir, "models").apply { mkdirs() }
            val destFile = File(cacheDir, fileName)

            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            destFile.absolutePath
        } catch (e: Exception) {
            Timber.e(e, "Error copying file")
            null
        }
    }
}

data class ModelSetupUiState(
    val selectedFile: File? = null,
    val selectedModel: LlmModel? = null,
    val isValidFile: Boolean = false
)
