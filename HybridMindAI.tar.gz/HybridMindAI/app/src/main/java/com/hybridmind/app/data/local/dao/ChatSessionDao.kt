package com.hybridmind.app.data.local.dao

import androidx.room.*
import com.hybridmind.app.data.local.entities.ChatSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatSessionDao {
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: ChatSessionEntity)
    
    @Update
    suspend fun update(session: ChatSessionEntity)
    
    @Delete
    suspend fun delete(session: ChatSessionEntity)
    
    @Query("DELETE FROM chat_sessions WHERE id = :sessionId")
    suspend fun deleteById(sessionId: String)
    
    @Query("DELETE FROM chat_sessions")
    suspend fun deleteAll()
    
    @Query("SELECT * FROM chat_sessions WHERE id = :sessionId")
    suspend fun getById(sessionId: String): ChatSessionEntity?
    
    @Query("SELECT * FROM chat_sessions ORDER BY isPinned DESC, updatedAt DESC")
    fun getAll(): Flow<List<ChatSessionEntity>>
    
    @Query("SELECT * FROM chat_sessions ORDER BY isPinned DESC, updatedAt DESC")
    suspend fun getAllSync(): List<ChatSessionEntity>
    
    @Query("UPDATE chat_sessions SET messageCount = (SELECT COUNT(*) FROM messages WHERE sessionId = :sessionId) WHERE id = :sessionId")
    suspend fun updateMessageCount(sessionId: String)
    
    @Query("UPDATE chat_sessions SET updatedAt = :timestamp WHERE id = :sessionId")
    suspend fun updateTimestamp(sessionId: String, timestamp: Long = System.currentTimeMillis())
}
