# HybridMind AI

Asisten AI Privat yang berjalan 100% secara lokal di perangkat Android menggunakan teknologi llama.cpp.

## Fitur

- **Local-First**: Semua data disimpan secara lokal, tidak ada data yang dikirim ke server
- **Hybrid Engine**: Local LLM + Web Search untuk informasi real-time
- **Modern UI**: Jetpack Compose dengan Material Design 3
- **Enkripsi**: Database terenkripsi dengan SQLCipher

## Persyaratan

- Android 8.0 (API 26) atau lebih tinggi
- RAM minimal 4GB (disarankan 6GB+)
- Storage minimal 3GB free space

## Cara Build

### Menggunakan Terminal

```bash
# Clone repository
git clone https://github.com/yourusername/HybridMindAI.git
cd HybridMindAI

# Build Debug APK
./gradlew assembleDebug

# Build Release APK
./gradlew assembleRelease
```

### Menggunakan Android Studio

1. Buka Android Studio
2. Pilih "Open an existing Android Studio project"
3. Pilih folder HybridMindAI
4. Tunggu Gradle sync selesai
5. Klik "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)"

## Struktur Proyek

```
app/
├── src/main/
│   ├── java/com/hybridmind/app/
│   │   ├── data/          # Repository implementations
│   │   ├── domain/        # Models, UseCases, Interfaces
│   │   ├── di/            # Hilt DI modules
│   │   ├── ui/            # Compose screens & ViewModels
│   │   ├── service/       # Foreground services
│   │   └── receiver/      # Battery monitor
│   ├── cpp/               # JNI native code
│   └── res/               # Resources
└── build.gradle.kts
```

## License

MIT License
