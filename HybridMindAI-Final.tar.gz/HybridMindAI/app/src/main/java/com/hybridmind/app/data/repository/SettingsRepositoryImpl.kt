package com.hybridmind.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.hybridmind.app.domain.model.AIPersonality
import com.hybridmind.app.domain.model.AppSettings
import com.hybridmind.app.domain.model.InferenceBackend
import com.hybridmind.app.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hybridmind_settings")

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SettingsRepository {

    private val dataStore = context.dataStore

    private object Keys {
        val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val PERSONALITY = stringPreferencesKey("personality")
        val BACKEND = stringPreferencesKey("backend")
        val USE_WEB_SEARCH = booleanPreferencesKey("use_web_search")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val SAVE_HISTORY = booleanPreferencesKey("save_history")
        val CONTEXT_LIMIT = intPreferencesKey("context_limit")
        val AUTO_SUMMARIZE = booleanPreferencesKey("auto_summarize")
        val BATTERY_SAVER_THRESHOLD = intPreferencesKey("battery_saver_threshold")
        val LANGUAGE = stringPreferencesKey("language")
        val LAST_MODEL_PATH = stringPreferencesKey("last_model_path")
    }

    override val settings: Flow<AppSettings> = dataStore.data.map { preferences ->
        AppSettings(
            systemPrompt = preferences[Keys.SYSTEM_PROMPT] ?: "Anda adalah HybridMind AI, asisten yang membantu.",
            personality = preferences[Keys.PERSONALITY]?.let { AIPersonality.valueOf(it) } ?: AIPersonality.FRIENDLY,
            backend = preferences[Keys.BACKEND]?.let { InferenceBackend.valueOf(it) } ?: InferenceBackend.CPU,
            useWebSearch = preferences[Keys.USE_WEB_SEARCH] ?: false,
            autoSpeak = preferences[Keys.AUTO_SPEAK] ?: false,
            saveHistory = preferences[Keys.SAVE_HISTORY] ?: true,
            contextLimit = preferences[Keys.CONTEXT_LIMIT] ?: 4096,
            autoSummarize = preferences[Keys.AUTO_SUMMARIZE] ?: true,
            batterySaverThreshold = preferences[Keys.BATTERY_SAVER_THRESHOLD] ?: 15,
            language = preferences[Keys.LANGUAGE] ?: "id"
        )
    }

    override suspend fun getSettings(): AppSettings = settings.first()

    override suspend fun updateSystemPrompt(prompt: String) {
        dataStore.edit { it[Keys.SYSTEM_PROMPT] = prompt }
    }

    override suspend fun updatePersonality(personality: AIPersonality) {
        dataStore.edit { it[Keys.PERSONALITY] = personality.name }
    }

    override suspend fun updateBackend(backend: InferenceBackend) {
        dataStore.edit { it[Keys.BACKEND] = backend.name }
    }

    override suspend fun setWebSearchEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.USE_WEB_SEARCH] = enabled }
    }

    override suspend fun setAutoSpeak(enabled: Boolean) {
        dataStore.edit { it[Keys.AUTO_SPEAK] = enabled }
    }

    override suspend fun setSaveHistory(enabled: Boolean) {
        dataStore.edit { it[Keys.SAVE_HISTORY] = enabled }
    }

    override suspend fun setContextLimit(limit: Int) {
        dataStore.edit { it[Keys.CONTEXT_LIMIT] = limit }
    }

    override suspend fun setAutoSummarize(enabled: Boolean) {
        dataStore.edit { it[Keys.AUTO_SUMMARIZE] = enabled }
    }

    override suspend fun setBatterySaverThreshold(threshold: Int) {
        dataStore.edit { it[Keys.BATTERY_SAVER_THRESHOLD] = threshold }
    }

    override suspend fun saveLastModelPath(path: String) {
        dataStore.edit { it[Keys.LAST_MODEL_PATH] = path }
    }

    override suspend fun getLastModelPath(): String? {
        return dataStore.data.map { it[Keys.LAST_MODEL_PATH] }.first()
    }

    override suspend fun clearSettings() {
        dataStore.edit { it.clear() }
    }
}
