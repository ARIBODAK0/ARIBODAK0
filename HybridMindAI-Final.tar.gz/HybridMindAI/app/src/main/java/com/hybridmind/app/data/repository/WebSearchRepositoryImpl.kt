package com.hybridmind.app.data.repository

import com.hybridmind.app.data.remote.api.DuckDuckGoApi
import com.hybridmind.app.domain.model.SearchResult
import com.hybridmind.app.domain.repository.WebSearchRepository
import com.hybridmind.app.domain.repository.needsRealtimeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WebSearchRepositoryImpl @Inject constructor(
    private val duckDuckGoApi: DuckDuckGoApi
) : WebSearchRepository {

    override suspend fun search(query: String, maxResults: Int): Result<List<SearchResult>> {
        return withContext(Dispatchers.IO) {
            try {
                val response = duckDuckGoApi.search(query)

                if (response.isSuccessful) {
                    val body = response.body()
                    val results = mutableListOf<SearchResult>()

                    body?.abstractText?.takeIf { it.isNotBlank() }?.let {
                        results.add(SearchResult(
                            title = body.heading ?: "Abstract",
                            url = body.abstractURL ?: "",
                            snippet = it,
                            source = body.abstractSource ?: "DuckDuckGo"
                        ))
                    }

                    body?.relatedTopics?.forEach { topic ->
                        topic.text?.takeIf { it.isNotBlank() }?.let {
                            results.add(SearchResult(
                                title = it.substringBefore("."),
                                url = topic.firstURL ?: "",
                                snippet = it,
                                source = "DuckDuckGo"
                            ))
                        }
                    }

                    body?.results?.forEach { result ->
                        result.text?.takeIf { it.isNotBlank() }?.let {
                            results.add(SearchResult(
                                title = it.substringBefore("."),
                                url = result.firstURL ?: "",
                                snippet = it,
                                source = "DuckDuckGo"
                            ))
                        }
                    }

                    Result.success(results.take(maxResults))
                } else {
                    Result.failure(Exception("Search failed: ${response.code()}"))
                }
            } catch (e: Exception) {
                Timber.e(e, "Web search error")
                Result.failure(e)
            }
        }
    }

    override fun needsRealtimeInfo(query: String): Boolean {
        return query.needsRealtimeInfo()
    }

    override suspend fun summarizeResults(results: List<SearchResult>, query: String): String {
        return withContext(Dispatchers.Default) {
            if (results.isEmpty()) {
                "Tidak ditemukan informasi relevan dari web."
            } else {
                buildString {
                    appendLine("Informasi dari web:")
                    results.take(3).forEachIndexed { index, result ->
                        appendLine("${index + 1}. ${result.title}")
                        appendLine("   ${result.snippet}")
                    }
                }
            }
        }
    }
}
