package com.hybridmind.app.data.remote.api

import com.hybridmind.app.data.remote.model.DuckDuckGoResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * DuckDuckGo Instant Answer API
 * Note: This is a simplified API. For production, consider using Serper.dev or similar
 */
interface DuckDuckGoApi {
    
    @GET("/")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String = "json",
        @Query("no_html") noHtml: Int = 1,
        @Query("skip_disambig") skipDisambig: Int = 1,
        @Query("no_redirect") noRedirect: Int = 1
    ): Response<DuckDuckGoResponse>
    
    companion object {
        const val BASE_URL = "https://api.duckduckgo.com/"
    }
}

/**
 * Alternative: Serper.dev API for Google Search results
 * More reliable for production use
 */
interface SerperApi {
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("num") numResults: Int = 5
    ): Response<SerperSearchResponse>
    
    companion object {
        const val BASE_URL = "https://google.serper.dev/"
    }
}

data class SerperSearchResponse(
    val searchParameters: SearchParameters? = null,
    val organic: List<OrganicResult>? = null,
    val answerBox: AnswerBox? = null,
    val knowledgeGraph: KnowledgeGraph? = null
)

data class SearchParameters(
    val q: String? = null,
    val gl: String? = null,
    val hl: String? = null,
    val num: Int? = null
)

data class OrganicResult(
    val title: String? = null,
    val link: String? = null,
    val snippet: String? = null,
    val position: Int? = null
)

data class AnswerBox(
    val title: String? = null,
    val answer: String? = null,
    val snippet: String? = null
)

data class KnowledgeGraph(
    val title: String? = null,
    val type: String? = null,
    val description: String? = null
)
