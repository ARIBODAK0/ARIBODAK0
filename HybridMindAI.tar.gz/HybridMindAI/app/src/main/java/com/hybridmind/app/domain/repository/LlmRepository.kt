package com.hybridmind.app.domain.repository

import com.hybridmind.app.domain.model.InferenceBackend
import com.hybridmind.app.domain.model.LlmModel
import com.hybridmind.app.domain.model.ModelLoadingState
import com.hybridmind.app.domain.model.ModelParameters
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * Repository interface for LLM operations
 */
interface LlmRepository {
    
    val loadingState: StateFlow<ModelLoadingState>
    val isModelLoaded: StateFlow<Boolean>
    val currentModel: StateFlow<LlmModel?>
    
    /**
     * Load a GGUF model from file path
     */
    suspend fun loadModel(filePath: String, parameters: ModelParameters = ModelParameters()): Result<LlmModel>
    
    /**
     * Unload the current model and free memory
     */
    suspend fun unloadModel()
    
    /**
     * Validate if file is a valid GGUF model
     */
    suspend fun validateModelFile(filePath: String): Result<Boolean>
    
    /**
     * Generate text completion
     */
    suspend fun generateCompletion(
        prompt: String,
        systemPrompt: String? = null,
        parameters: ModelParameters? = null,
        onToken: suspend (String) -> Unit
    ): Result<String>
    
    /**
     * Generate chat completion with conversation history
     */
    suspend fun generateChatCompletion(
        messages: List<Pair<String, String>>, // List of (role, content)
        systemPrompt: String? = null,
        parameters: ModelParameters? = null,
        onToken: suspend (String) -> Unit
    ): Result<String>
    
    /**
     * Stop generation
     */
    fun stopGeneration()
    
    /**
     * Check if model is currently generating
     */
    fun isGenerating(): Boolean
    
    /**
     * Get model info from file without loading
     */
    suspend fun getModelInfo(filePath: String): Result<LlmModel>
    
    /**
     * Set inference backend (CPU, NNAPI, Vulkan)
     */
    suspend fun setBackend(backend: InferenceBackend)
    
    /**
     * Get current backend
     */
    fun getCurrentBackend(): InferenceBackend
    
    /**
     * Get RAM usage statistics
     */
    fun getMemoryUsage(): Pair<Long, Long> // (used, total) in bytes
    
    /**
     * Tokenize text and return token count
     */
    suspend fun tokenize(text: String): Result<Int>
}
