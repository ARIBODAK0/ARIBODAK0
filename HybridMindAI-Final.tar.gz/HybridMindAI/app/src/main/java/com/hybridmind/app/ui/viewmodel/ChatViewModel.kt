package com.hybridmind.app.ui.viewmodel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybridmind.app.domain.model.ChatMessage
import com.hybridmind.app.domain.model.ChatSession
import com.hybridmind.app.domain.model.MessageRole
import com.hybridmind.app.domain.model.SendMessageState
import com.hybridmind.app.domain.repository.SettingsRepository
import com.hybridmind.app.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sendMessageUseCase: SendMessageUseCase,
    private val createChatSessionUseCase: CreateChatSessionUseCase,
    private val getChatSessionsUseCase: GetChatSessionsUseCase,
    private val deleteChatSessionUseCase: DeleteChatSessionUseCase,
    private val chatRepository: com.hybridmind.app.domain.repository.ChatRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    init {
        loadSessions()
        createNewSession()
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            try {
                val settings = settingsRepository.getSettings()
                _uiState.update { it.copy(webSearchEnabled = settings.useWebSearch) }
            } catch (e: Exception) {
                Timber.e(e, "Error loading settings")
            }
        }
    }

    private fun loadSessions() {
        viewModelScope.launch {
            try {
                getChatSessionsUseCase().collect { sessions ->
                    _uiState.update { it.copy(sessions = sessions) }
                }
            } catch (e: Exception) {
                Timber.e(e, "Error loading sessions")
            }
        }
    }

    fun createNewSession() {
        viewModelScope.launch {
            try {
                val session = createChatSessionUseCase("Chat Baru")
                _uiState.update {
                    it.copy(currentSessionId = session.id, currentSessionTitle = session.title)
                }
                _messages.value = emptyList()

                val welcomeMessage = ChatMessage(
                    sessionId = session.id,
                    role = MessageRole.ASSISTANT,
                    content = "Halo! Saya HybridMind AI. Semua percakapan ini privat dan berjalan lokal di perangkat Anda."
                )
                _messages.value = listOf(welcomeMessage)
            } catch (e: Exception) {
                Timber.e(e, "Error creating session")
            }
        }
    }

    fun loadSession(sessionId: String) {
        viewModelScope.launch {
            val session = _uiState.value.sessions.find { it.id == sessionId }
            session?.let {
                _uiState.update { it.copy(currentSessionId = sessionId, currentSessionTitle = session.title) }
                _messages.value = emptyList()
            }
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            try {
                deleteChatSessionUseCase(sessionId)
                if (_uiState.value.currentSessionId == sessionId) {
                    createNewSession()
                }
            } catch (e: Exception) {
                Timber.e(e, "Error deleting session")
            }
        }
    }

    fun onInputChange(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage() {
        val message = _uiState.value.inputText.trim()
        if (message.isEmpty()) return
        val sessionId = _uiState.value.currentSessionId ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(inputText = "", isGenerating = true) }

            sendMessageUseCase(sessionId, message, _uiState.value.webSearchEnabled)
                .collect { state ->
                    when (state) {
                        is SendMessageState.Loading -> _uiState.update { it.copy(isGenerating = true) }
                        is SendMessageState.Searching -> _uiState.update { it.copy(isSearching = true) }
                        is SendMessageState.Streaming -> {
                            _uiState.update { it.copy(isGenerating = true, isSearching = false) }
                            updateLastAssistantMessage(state.partialResponse, state.searchResults)
                        }
                        is SendMessageState.Success -> {
                            _uiState.update { it.copy(isGenerating = false, isSearching = false) }
                            updateLastAssistantMessage(state.response, state.searchResults, isComplete = true)
                        }
                        is SendMessageState.Error -> {
                            _uiState.update { it.copy(isGenerating = false, isSearching = false, errorMessage = state.message) }
                        }
                    }
                }
        }
    }

    private fun updateLastAssistantMessage(content: String, searchResults: List<com.hybridmind.app.domain.model.SearchResult>?, isComplete: Boolean = false) {
        val currentMessages = _messages.value.toMutableList()
        val lastIndex = currentMessages.indexOfLast { it.role == MessageRole.ASSISTANT }

        if (lastIndex >= 0 && currentMessages[lastIndex].isStreaming) {
            currentMessages[lastIndex] = currentMessages[lastIndex].copy(
                content = content, isStreaming = !isComplete, searchResults = searchResults
            )
        } else {
            currentMessages.add(ChatMessage(
                sessionId = _uiState.value.currentSessionId ?: "",
                role = MessageRole.ASSISTANT,
                content = content,
                isStreaming = !isComplete,
                searchResults = searchResults
            ))
        }
        _messages.value = currentMessages
    }

    fun toggleWebSearch() {
        _uiState.update { it.copy(webSearchEnabled = !it.webSearchEnabled) }
        viewModelScope.launch {
            settingsRepository.setWebSearchEnabled(_uiState.value.webSearchEnabled)
        }
    }

    fun copyMessage(content: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Message", content))
    }

    fun regenerateMessage(message: ChatMessage) {
        val messageIndex = _messages.value.indexOf(message)
        if (messageIndex > 0) {
            val userMessage = _messages.value[messageIndex - 1]
            if (userMessage.role == MessageRole.USER) {
                _messages.value = _messages.value.take(messageIndex)
                _uiState.update { it.copy(inputText = userMessage.content) }
                sendMessage()
            }
        }
    }

    fun saveToNotes(message: ChatMessage) {
        // TODO: Implement
    }
}

data class ChatUiState(
    val currentSessionId: String? = null,
    val currentSessionTitle: String = "Chat Baru",
    val inputText: String = "",
    val isGenerating: Boolean = false,
    val isSearching: Boolean = false,
    val webSearchEnabled: Boolean = false,
    val errorMessage: String? = null,
    val sessions: List<ChatSession> = emptyList()
)
