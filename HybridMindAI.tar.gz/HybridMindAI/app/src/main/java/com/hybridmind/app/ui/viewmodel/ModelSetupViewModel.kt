package com.hybridmind.app.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybridmind.app.domain.model.ModelLoadingState
import com.hybridmind.app.domain.usecase.LoadModelUseCase
import com.hybridmind.app.domain.usecase.ValidateModelFileUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ModelSetupViewModel @Inject constructor(
    private val loadModelUseCase: LoadModelUseCase,
    private val validateModelFileUseCase: ValidateModelFileUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ModelSetupUiState())
    val uiState: StateFlow<ModelSetupUiState> = _uiState.asStateFlow()

    private val _loadingState = MutableStateFlow<ModelLoadingState>(ModelLoadingState.Idle)
    val loadingState: StateFlow<ModelLoadingState> = _loadingState.asStateFlow()

    fun onFileSelected(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                _loadingState.value = ModelLoadingState.Validating

                // Get file path from URI
                val filePath = getPathFromUri(context, uri)
                if (filePath == null) {
                    _loadingState.value = ModelLoadingState.Error(
                        "Tidak dapat mengakses file",
                        com.hybridmind.app.domain.model.ErrorType.FILE_NOT_FOUND
                    )
                    return@launch
                }

                val file = File(filePath)
                if (!file.exists()) {
                    _loadingState.value = ModelLoadingState.Error(
                        "File tidak ditemukan",
                        com.hybridmind.app.domain.model.ErrorType.FILE_NOT_FOUND
                    )
                    return@launch
                }

                // Check file extension
                if (!file.name.endsWith(".gguf", ignoreCase = true)) {
                    _loadingState.value = ModelLoadingState.Error(
                        "File harus berformat .gguf",
                        com.hybridmind.app.domain.model.ErrorType.UNSUPPORTED_FORMAT
                    )
                    return@launch
                }

                _uiState.update {
                    it.copy(
                        selectedFile = file,
                        isValidFile = true
                    )
                }

                _loadingState.value = ModelLoadingState.Idle

            } catch (e: Exception) {
                Timber.e(e, "Error selecting file")
                _loadingState.value = ModelLoadingState.Error(
                    e.message ?: "Error tidak diketahui",
                    com.hybridmind.app.domain.model.ErrorType.UNKNOWN
                )
            }
        }
    }

    fun loadModel() {
        val file = _uiState.value.selectedFile ?: return

        viewModelScope.launch {
            _loadingState.value = ModelLoadingState.Loading(0)

            loadModelUseCase(file.absolutePath)
                .onSuccess { model ->
                    _uiState.update { it.copy(selectedModel = model) }
                    _loadingState.value = ModelLoadingState.Success(model)
                }
                .onFailure { error ->
                    Timber.e(error, "Failed to load model")
                    _loadingState.value = ModelLoadingState.Error(
                        error.message ?: "Gagal memuat model",
                        com.hybridmind.app.domain.model.ErrorType.UNKNOWN
                    )
                }
        }
    }

    private fun getPathFromUri(context: Context, uri: Uri): String? {
        // Handle different URI schemes
        return when (uri.scheme) {
            "file" -> uri.path
            "content" -> {
                // Try to get file path from content URI
                val projection = arrayOf(android.provider.MediaStore.MediaColumns.DATA)
                context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val columnIndex = cursor.getColumnIndexOrThrow(android.provider.MediaStore.MediaColumns.DATA)
                        cursor.getString(columnIndex)
                    } else null
                } ?: copyUriToCache(context, uri)
            }
            else -> null
        }
    }

    private fun copyUriToCache(context: Context, uri: Uri): String? {
        return try {
            val fileName = getFileName(context, uri) ?: "model.gguf"
            val cacheDir = File(context.cacheDir, "models").apply { mkdirs() }
            val destFile = File(cacheDir, fileName)

            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            destFile.absolutePath
        } catch (e: Exception) {
            Timber.e(e, "Error copying file to cache")
            null
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) {
                    return cursor.getString(nameIndex)
                }
            }
        }
        return uri.lastPathSegment
    }
}

data class ModelSetupUiState(
    val selectedFile: File? = null,
    val selectedModel: com.hybridmind.app.domain.model.LlmModel? = null,
    val isValidFile: Boolean = false
)
