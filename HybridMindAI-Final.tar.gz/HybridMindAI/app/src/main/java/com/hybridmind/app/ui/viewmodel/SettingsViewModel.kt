package com.hybridmind.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hybridmind.app.domain.model.AIPersonality
import com.hybridmind.app.domain.model.AppSettings
import com.hybridmind.app.domain.model.InferenceBackend
import com.hybridmind.app.domain.model.LlmModel
import com.hybridmind.app.domain.repository.LlmRepository
import com.hybridmind.app.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val llmRepository: LlmRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        loadSettings()
        loadCurrentModel()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            settingsRepository.settings.collect { settings ->
                _uiState.update {
                    it.copy(
                        systemPrompt = settings.systemPrompt,
                        personality = settings.personality,
                        backend = settings.backend,
                        autoSummarize = settings.autoSummarize,
                        saveHistory = settings.saveHistory
                    )
                }
            }
        }
    }

    private fun loadCurrentModel() {
        viewModelScope.launch {
            llmRepository.currentModel.collect { model ->
                _uiState.update { it.copy(currentModel = model) }
            }
        }
    }

    fun updateSystemPrompt(prompt: String) {
        _uiState.update { it.copy(systemPrompt = prompt) }
        viewModelScope.launch { settingsRepository.updateSystemPrompt(prompt) }
    }

    fun updatePersonality(personality: AIPersonality) {
        _uiState.update { it.copy(personality = personality) }
        viewModelScope.launch {
            settingsRepository.updatePersonality(personality)
            settingsRepository.updateSystemPrompt(personality.prompt)
        }
    }

    fun updateBackend(backend: InferenceBackend) {
        _uiState.update { it.copy(backend = backend) }
        viewModelScope.launch {
            llmRepository.setBackend(backend)
            settingsRepository.updateBackend(backend)
        }
    }

    fun setAutoSummarize(enabled: Boolean) {
        _uiState.update { it.copy(autoSummarize = enabled) }
        viewModelScope.launch { settingsRepository.setAutoSummarize(enabled) }
    }

    fun setSaveHistory(enabled: Boolean) {
        _uiState.update { it.copy(saveHistory = enabled) }
        viewModelScope.launch { settingsRepository.setSaveHistory(enabled) }
    }

    fun unloadModel() {
        viewModelScope.launch { llmRepository.unloadModel() }
    }
}

data class SettingsUiState(
    val systemPrompt: String = "",
    val personality: AIPersonality = AIPersonality.FRIENDLY,
    val backend: InferenceBackend = InferenceBackend.CPU,
    val autoSummarize: Boolean = true,
    val saveHistory: Boolean = true,
    val currentModel: LlmModel? = null
)
