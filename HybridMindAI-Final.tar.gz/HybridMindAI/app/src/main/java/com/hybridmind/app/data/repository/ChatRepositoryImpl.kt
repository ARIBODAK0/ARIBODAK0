package com.hybridmind.app.data.repository

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hybridmind.app.data.local.dao.ChatMessageDao
import com.hybridmind.app.data.local.dao.ChatSessionDao
import com.hybridmind.app.data.local.entities.ChatMessageEntity
import com.hybridmind.app.data.local.entities.ChatSessionEntity
import com.hybridmind.app.domain.model.ChatMessage
import com.hybridmind.app.domain.model.ChatSession
import com.hybridmind.app.domain.model.MessageRole
import com.hybridmind.app.domain.model.SearchResult
import com.hybridmind.app.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import timber.log.Timber
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val sessionDao: ChatSessionDao,
    private val messageDao: ChatMessageDao,
    private val gson: Gson
) : ChatRepository {

    override suspend fun createSession(title: String): ChatSession {
        val entity = ChatSessionEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        sessionDao.insert(entity)
        return entity.toDomain()
    }

    override suspend fun getSession(sessionId: String): ChatSession? {
        return sessionDao.getById(sessionId)?.toDomain()
    }

    override suspend fun getAllSessions(): Flow<List<ChatSession>> {
        return sessionDao.getAll().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun updateSession(session: ChatSession) {
        sessionDao.update(session.toEntity())
    }

    override suspend fun deleteSession(sessionId: String) {
        sessionDao.deleteById(sessionId)
    }

    override suspend fun deleteAllSessions() {
        sessionDao.deleteAll()
        messageDao.deleteAll()
    }

    override suspend fun insertMessage(message: ChatMessage) {
        messageDao.insert(message.toEntity(gson))
        sessionDao.updateTimestamp(message.sessionId)
        sessionDao.updateMessageCount(message.sessionId)
    }

    override suspend fun insertMessages(messages: List<ChatMessage>) {
        messageDao.insertAll(messages.map { it.toEntity(gson) })
        messages.firstOrNull()?.let {
            sessionDao.updateTimestamp(it.sessionId)
            sessionDao.updateMessageCount(it.sessionId)
        }
    }

    override suspend fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>> {
        return messageDao.getBySessionId(sessionId).map { entities ->
            entities.map { it.toDomain(gson) }
        }
    }

    override suspend fun getMessageCountForSession(sessionId: String): Int {
        return messageDao.getCountBySessionId(sessionId)
    }

    override suspend fun deleteMessage(messageId: String) {
        messageDao.deleteById(messageId)
    }

    override suspend fun deleteMessagesForSession(sessionId: String) {
        messageDao.deleteBySessionId(sessionId)
    }

    override suspend fun updateMessage(message: ChatMessage) {
        messageDao.update(message.toEntity(gson))
    }

    override suspend fun getRecentMessagesForContext(sessionId: String, limit: Int): List<ChatMessage> {
        return messageDao.getContextMessages(sessionId, limit)
            .map { it.toDomain(gson) }
            .reversed()
    }

    override suspend fun getContextTokenCount(sessionId: String): Int {
        val messages = messageDao.getBySessionIdSync(sessionId)
        return messages.sumOf { it.content.length / 4 }
    }

    override suspend fun pruneOldMessages(sessionId: String, keepCount: Int) {
        try {
            messageDao.pruneOldMessages(sessionId, keepCount)
            sessionDao.updateMessageCount(sessionId)
        } catch (e: Exception) {
            Timber.e(e, "Error pruning old messages")
        }
    }

    private fun ChatSessionEntity.toDomain() = ChatSession(
        id = id, title = title, createdAt = createdAt,
        updatedAt = updatedAt, messageCount = messageCount, isPinned = isPinned
    )

    private fun ChatSession.toEntity() = ChatSessionEntity(
        id = id, title = title, createdAt = createdAt,
        updatedAt = updatedAt, messageCount = messageCount, isPinned = isPinned
    )

    private fun ChatMessageEntity.toDomain(gson: Gson) = ChatMessage(
        id = id, sessionId = sessionId, role = MessageRole.valueOf(role),
        content = content, timestamp = timestamp,
        searchResults = searchResultsJson?.let {
            gson.fromJson<List<SearchResult>>(it, object : TypeToken<List<SearchResult>>() {}.type)
        },
        error = error
    )

    private fun ChatMessage.toEntity(gson: Gson) = ChatMessageEntity(
        id = id, sessionId = sessionId, role = role.name,
        content = content, timestamp = timestamp,
        searchResultsJson = searchResults?.let { gson.toJson(it) },
        error = error
    )
}
