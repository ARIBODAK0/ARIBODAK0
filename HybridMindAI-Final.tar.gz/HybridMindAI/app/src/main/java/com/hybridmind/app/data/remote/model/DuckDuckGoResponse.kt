package com.hybridmind.app.data.remote.model

import com.google.gson.annotations.SerializedName

data class DuckDuckGoResponse(
    @SerializedName("AbstractText") val abstractText: String? = null,
    @SerializedName("AbstractURL") val abstractURL: String? = null,
    @SerializedName("AbstractSource") val abstractSource: String? = null,
    @SerializedName("Heading") val heading: String? = null,
    @SerializedName("RelatedTopics") val relatedTopics: List<RelatedTopic>? = null,
    @SerializedName("Results") val results: List<SearchResultItem>? = null,
    @SerializedName("Answer") val answer: String? = null
)

data class RelatedTopic(
    @SerializedName("FirstURL") val firstURL: String? = null,
    @SerializedName("Text") val text: String? = null,
    @SerializedName("Result") val result: String? = null
)

data class SearchResultItem(
    @SerializedName("FirstURL") val firstURL: String? = null,
    @SerializedName("Text") val text: String? = null
)
