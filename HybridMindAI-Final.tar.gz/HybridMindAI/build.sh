#!/bin/bash

# Build script for HybridMind AI

echo "================================"
echo "HybridMind AI Build Script"
echo "================================"
echo ""

# Check if JAVA_HOME is set
if [ -z "$JAVA_HOME" ]; then
    echo "WARNING: JAVA_HOME is not set. Using system default Java."
fi

# Make gradlew executable
chmod +x gradlew

# Clean previous builds
echo "Cleaning previous builds..."
./gradlew clean

# Build Debug APK
echo ""
echo "Building Debug APK..."
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo ""
    echo "================================"
    echo "Debug APK built successfully!"
    echo "Location: app/build/outputs/apk/debug/"
    echo "================================"
else
    echo ""
    echo "================================"
    echo "Debug build failed!"
    echo "================================"
    exit 1
fi

# Build Release APK
echo ""
echo "Building Release APK..."
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo ""
    echo "================================"
    echo "Release APK built successfully!"
    echo "Location: app/build/outputs/apk/release/"
    echo "================================"
else
    echo ""
    echo "================================"
    echo "Release build failed!"
    echo "================================"
    exit 1
fi

echo ""
echo "All builds completed successfully!"
