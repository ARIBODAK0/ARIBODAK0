package com.hybridmind.app.domain.repository

import com.hybridmind.app.domain.model.SearchResult

/**
 * Repository interface for web search operations
 */
interface WebSearchRepository {
    
    /**
     * Search the web for the given query
     * @param query The search query
     * @param maxResults Maximum number of results to return (default: 5)
     * @return Result containing list of search results or error
     */
    suspend fun search(query: String, maxResults: Int = 5): Result<List<SearchResult>>
    
    /**
     * Check if the query likely needs real-time information
     * Uses heuristics to determine if web search is needed
     */
    fun needsRealtimeInfo(query: String): Boolean
    
    /**
     * Summarize search results into a coherent text
     */
    suspend fun summarizeResults(results: List<SearchResult>, query: String): String
}

/**
 * Keywords that indicate need for real-time information
 */
val REALTIME_KEYWORDS = setOf(
    "berita", "news", "terbaru", "latest", "hari ini", "today",
    "cuaca", "weather", "harga", "price", "saham", "stock",
    "jadwal", "schedule", "skor", "score", "hasil", "result",
    "kurs", "exchange rate", "bitcoin", "crypto",
    "pemilu", "election", "covid", "pandemi", "pandemic",
    "2024", "2025", "2026", "tahun ini", "this year",
    "sekarang", "now", "saat ini", "currently", "recent"
)

fun String.needsRealtimeInfo(): Boolean {
    val lowercase = this.lowercase()
    return REALTIME_KEYWORDS.any { keyword -> lowercase.contains(keyword) }
}
