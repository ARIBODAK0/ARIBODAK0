package com.hybridmind.app.data.remote.api

import com.hybridmind.app.data.remote.model.DuckDuckGoResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface DuckDuckGoApi {
    @GET("/")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String = "json",
        @Query("no_html") noHtml: Int = 1,
        @Query("skip_disambig") skipDisambig: Int = 1,
        @Query("no_redirect") noRedirect: Int = 1
    ): Response<DuckDuckGoResponse>

    companion object {
        const val BASE_URL = "https://api.duckduckgo.com/"
    }
}
