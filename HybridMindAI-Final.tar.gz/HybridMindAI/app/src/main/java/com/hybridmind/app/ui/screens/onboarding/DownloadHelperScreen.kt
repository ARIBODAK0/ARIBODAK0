package com.hybridmind.app.ui.screens.onboarding

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadHelperScreen(onNavigateBack: () -> Unit, onModelDownloaded: () -> Unit) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Download Model AI") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(scrollState).padding(16.dp)
        ) {
            Text(text = "Anda perlu mengunduh model GGUF dari HuggingFace. Berikut rekomendasi model:", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(24.dp))
            Text(text = "Rekomendasi Model", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(12.dp))

            ModelRecommendationCard(
                name = "Microsoft Phi-3 Mini (3.8B)",
                description = "Cepat & ringan, cocok untuk percakapan umum",
                size = "~2.3 GB (Q4)",
                url = "https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf",
                onOpenUrl = { openUrl(context, it) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            ModelRecommendationCard(
                name = "Google Gemma 2B",
                description = "Model ringan dari Google, sangat efisien",
                size = "~1.5 GB (Q4)",
                url = "https://huggingface.co/google/gemma-2b-it-gpu",
                onOpenUrl = { openUrl(context, it) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            ModelRecommendationCard(
                name = "Alibaba Qwen2 7B",
                description = "Model multibahasa yang kuat (termasuk Indonesia)",
                size = "~4.5 GB (Q4)",
                url = "https://huggingface.co/Qwen/Qwen2-7B-Instruct-GGUF",
                onOpenUrl = { openUrl(context, it) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Help, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Cara Download & Simpan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    TutorialStep("1", "Klik tombol \"Buka HuggingFace\" di bawah")
                    TutorialStep("2", "Pilih model dan download file .gguf")
                    TutorialStep("3", "Simpan file di folder Downloads atau Documents")
                    TutorialStep("4", "Kembali ke aplikasi dan pilih file tersebut")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(onClick = { openUrl(context, "https://huggingface.co/models?search=gguf") }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Buka HuggingFace", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(onClick = onModelDownloaded, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Text(text = "Saya Sudah Download", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun ModelRecommendationCard(name: String, description: String, size: String, url: String, onOpenUrl: (String) -> Unit) {
    Card(onClick = { onOpenUrl(url) }, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(text = description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = size, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            Icon(imageVector = Icons.Default.OpenInNew, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TutorialStep(number: String, text: String) {
    Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Box(modifier = Modifier.size(24.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
            Text(text = number, style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(text = text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.padding(top = 2.dp))
    }
}

private fun openUrl(context: android.content.Context, url: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    context.startActivity(intent)
}
