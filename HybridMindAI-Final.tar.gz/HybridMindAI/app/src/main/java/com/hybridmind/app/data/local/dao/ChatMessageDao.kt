package com.hybridmind.app.data.local.dao

import androidx.room.*
import com.hybridmind.app.data.local.entities.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<ChatMessageEntity>)

    @Update
    suspend fun update(message: ChatMessageEntity)

    @Delete
    suspend fun delete(message: ChatMessageEntity)

    @Query("DELETE FROM messages WHERE id = :messageId")
    suspend fun deleteById(messageId: String)

    @Query("DELETE FROM messages WHERE sessionId = :sessionId")
    suspend fun deleteBySessionId(sessionId: String)

    @Query("DELETE FROM messages")
    suspend fun deleteAll()

    @Query("SELECT * FROM messages WHERE id = :messageId")
    suspend fun getById(messageId: String): ChatMessageEntity?

    @Query("SELECT * FROM messages WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getBySessionId(sessionId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM messages WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getBySessionIdSync(sessionId: String): List<ChatMessageEntity>

    @Query("SELECT * FROM messages WHERE sessionId = :sessionId ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentBySessionId(sessionId: String, limit: Int): List<ChatMessageEntity>

    @Query("SELECT COUNT(*) FROM messages WHERE sessionId = :sessionId")
    suspend fun getCountBySessionId(sessionId: String): Int

    @Query("DELETE FROM messages WHERE sessionId = :sessionId AND id NOT IN (SELECT id FROM messages WHERE sessionId = :sessionId ORDER BY timestamp DESC LIMIT :keepCount)")
    suspend fun pruneOldMessages(sessionId: String, keepCount: Int)

    @Query("SELECT * FROM messages WHERE sessionId = :sessionId AND role != 'SYSTEM' ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getContextMessages(sessionId: String, limit: Int): List<ChatMessageEntity>
}
