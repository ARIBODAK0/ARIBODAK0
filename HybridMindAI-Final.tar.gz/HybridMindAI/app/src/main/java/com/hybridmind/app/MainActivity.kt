package com.hybridmind.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.hybridmind.app.ui.screens.chat.ChatScreen
import com.hybridmind.app.ui.screens.onboarding.DownloadHelperScreen
import com.hybridmind.app.ui.screens.onboarding.ModelSetupScreen
import com.hybridmind.app.ui.screens.onboarding.WelcomeScreen
import com.hybridmind.app.ui.screens.settings.SettingsScreen
import com.hybridmind.app.ui.theme.HybridMindTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            HybridMindTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HybridMindApp()
                }
            }
        }
    }
}

@Composable
fun HybridMindApp() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Welcome.route
    ) {
        composable(Screen.Welcome.route) {
            WelcomeScreen(
                onNavigateToModelSetup = {
                    navController.navigate(Screen.ModelSetup.route) {
                        popUpTo(Screen.Welcome.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.ModelSetup.route) {
            ModelSetupScreen(
                onNavigateToDownloadHelper = {
                    navController.navigate(Screen.DownloadHelper.route)
                },
                onNavigateToChat = {
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.ModelSetup.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.DownloadHelper.route) {
            DownloadHelperScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onModelDownloaded = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.Chat.route) {
            ChatScreen(
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object ModelSetup : Screen("model_setup")
    object DownloadHelper : Screen("download_helper")
    object Chat : Screen("chat")
    object Settings : Screen("settings")
}
