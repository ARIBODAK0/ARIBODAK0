#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <android/log.h>

#define LOG_TAG "LlamaWrapper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/**
 * LlamaWrapper - C++ wrapper class for llama.cpp
 * 
 * This class provides a clean interface to llama.cpp functionality.
 * In production, this would be linked with the actual llama.cpp library.
 */

class LlamaWrapper {
public:
    struct ModelParams {
        int contextSize = 4096;
        int batchSize = 512;
        int threads = 4;
        bool useGpu = true;
        int gpuLayers = 0;
        float temperature = 0.7f;
        float topP = 0.9f;
        int topK = 40;
        float repeatPenalty = 1.1f;
    };

    struct GenerationParams {
        int maxTokens = 2048;
        std::string stopSequence = "";
    };

    LlamaWrapper() = default;
    ~LlamaWrapper() {
        unloadModel();
    }

    // Delete copy constructor and assignment
    LlamaWrapper(const LlamaWrapper&) = delete;
    LlamaWrapper& operator=(const LlamaWrapper&) = delete;

    bool loadModel(const std::string& modelPath, const ModelParams& params) {
        std::lock_guard<std::mutex> lock(m_mutex);

        LOGI("Loading model from: %s", modelPath.c_str());
        LOGI("Context size: %d, Threads: %d", params.contextSize, params.threads);

        // TODO: Actual llama.cpp implementation
        // llama_model_params model_params = llama_model_default_params();
        // model_params.n_gpu_layers = params.gpuLayers;
        // m_model = llama_load_model_from_file(modelPath.c_str(), model_params);
        //
        // if (!m_model) {
        //     LOGE("Failed to load model");
        //     return false;
        // }
        //
        // llama_context_params ctx_params = llama_context_default_params();
        // ctx_params.n_ctx = params.contextSize;
        // ctx_params.n_threads = params.threads;
        // ctx_params.n_threads_batch = params.threads;
        // m_ctx = llama_new_context_with_model(m_model, ctx_params);

        m_params = params;
        m_isLoaded = true;

        LOGI("Model loaded successfully");
        return true;
    }

    void unloadModel() {
        std::lock_guard<std::mutex> lock(m_mutex);

        if (!m_isLoaded) return;

        // TODO: Actual llama.cpp cleanup
        // llama_free(m_ctx);
        // llama_free_model(m_model);
        // llama_backend_free();

        m_isLoaded = false;
        LOGI("Model unloaded");
    }

    std::string generate(
        const std::string& prompt,
        const GenerationParams& genParams,
        std::function<void(const std::string&)> tokenCallback = nullptr
    ) {
        std::lock_guard<std::mutex> lock(m_mutex);

        if (!m_isLoaded) {
            LOGE("Model not loaded");
            return "";
        }

        LOGI("Generating for prompt length: %zu", prompt.length());

        m_isGenerating = true;
        std::string result;

        // TODO: Actual llama.cpp generation
        // 1. Tokenize prompt
        // 2. Evaluate tokens
        // 3. Sample and generate tokens one by one
        // 4. Call tokenCallback for each token
        // 5. Check for stop conditions

        // Placeholder implementation
        result = generatePlaceholderResponse(prompt, genParams, tokenCallback);

        m_isGenerating = false;
        return result;
    }

    void stopGeneration() {
        m_isGenerating = false;
        LOGI("Generation stopped");
    }

    bool isGenerating() const {
        return m_isGenerating;
    }

    int getContextSizeUsed() const {
        // TODO: Return actual context size from llama.cpp
        return 0;
    }

    std::vector<int> tokenize(const std::string& text) {
        std::lock_guard<std::mutex> lock(m_mutex);

        // TODO: Actual tokenization using llama.cpp
        // return llama_tokenize(m_ctx, text.c_str(), text.length(), ...);

        return std::vector<int>();
    }

    bool isLoaded() const {
        return m_isLoaded;
    }

    void setBackend(int backend) {
        // Backend: 0=CPU, 1=NNAPI, 2=Vulkan, 3=OpenCL
        LOGI("Setting backend to: %d", backend);
        // TODO: Implement backend switching
    }

private:
    // TODO: Actual llama.cpp types
    // llama_model* m_model = nullptr;
    // llama_context* m_ctx = nullptr;

    ModelParams m_params;
    bool m_isLoaded = false;
    bool m_isGenerating = false;
    mutable std::mutex m_mutex;

    std::string generatePlaceholderResponse(
        const std::string& prompt,
        const GenerationParams& params,
        std::function<void(const std::string&)>& callback
    ) {
        // Placeholder response for testing
        std::string response =
            "Halo! Saya adalah HybridMind AI, asisten pintar yang berjalan langsung di perangkat Anda.\n\n";

        if (callback) {
            // Simulate streaming
            const char* chars = response.c_str();
            for (size_t i = 0; i < response.length() && m_isGenerating; ++i) {
                std::string token(1, chars[i]);
                callback(token);
            }
        }

        return response;
    }
};

// Global instance (in production, use dependency injection)
static std::unique_ptr<LlamaWrapper> g_llamaWrapper = std::make_unique<LlamaWrapper>();

// C API for JNI
extern "C" {

LlamaWrapper* getLlamaWrapper() {
    return g_llamaWrapper.get();
}

} // extern "C"
