package com.hybridmind.app.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hybridmind.app.domain.model.AIPersonality
import com.hybridmind.app.domain.model.InferenceBackend
import com.hybridmind.app.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onNavigateBack: () -> Unit, viewModel: SettingsViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pengaturan") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(scrollState).padding(16.dp)) {
            SettingsSection(title = "System Prompt") {
                OutlinedTextField(
                    value = uiState.systemPrompt,
                    onValueChange = viewModel::updateSystemPrompt,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Anda adalah asisten AI yang membantu...") },
                    minLines = 3,
                    maxLines = 6,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            SettingsSection(title = "Kepribadian AI") {
                Column {
                    AIPersonality.entries.forEach { personality ->
                        PersonalityOption(
                            personality = personality,
                            isSelected = uiState.personality == personality,
                            onSelect = { viewModel.updatePersonality(personality) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            SettingsSection(title = "Konfigurasi Hardware") {
                Column {
                    BackendOption(title = "Gunakan NNAPI", subtitle = "AI Accelerator (lebih cepat)", isSelected = uiState.backend == InferenceBackend.NNAPI, onSelect = { viewModel.updateBackend(InferenceBackend.NNAPI) })
                    BackendOption(title = "Gunakan Vulkan", subtitle = "GPU dengan Vulkan (eksperimental)", isSelected = uiState.backend == InferenceBackend.VULKAN, onSelect = { viewModel.updateBackend(InferenceBackend.VULKAN) })
                    BackendOption(title = "CPU Only Mode", subtitle = "Paling stabil", isSelected = uiState.backend == InferenceBackend.CPU, onSelect = { viewModel.updateBackend(InferenceBackend.CPU) })
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            uiState.currentModel?.let { model ->
                SettingsSection(title = "Informasi Model") {
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            InfoRow("Nama", model.name)
                            InfoRow("Kuantasi", model.quantization.name)
                            InfoRow("Konteks", "${model.contextLength} tokens")
                            InfoRow("Ukuran", formatFileSize(model.fileSize))
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            SettingsSection(title = "Pengaturan Lain") {
                SettingsToggle(title = "Auto-Ringkas Konteks", subtitle = "Ringkas pesan lama saat penuh", checked = uiState.autoSummarize, onCheckedChange = viewModel::setAutoSummarize)
                SettingsToggle(title = "Simpan Riwayat", subtitle = "Simpan percakapan ke database", checked = uiState.saveHistory, onCheckedChange = viewModel::setSaveHistory)
            }

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedButton(onClick = { viewModel.unloadModel(); onNavigateBack() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                Icon(Icons.Default.PowerSettingsNew, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Unload Model")
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Versi 1.0.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun PersonalityOption(personality: AIPersonality, isSelected: Boolean, onSelect: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onSelect() }.background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = isSelected, onClick = onSelect)
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = personality.displayName, style = MaterialTheme.typography.bodyMedium, fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal)
            Text(text = personality.prompt.take(50) + "...", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BackendOption(title: String, subtitle: String, isSelected: Boolean, onSelect: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onSelect() }.background(if (isSelected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = isSelected, onClick = onSelect)
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal)
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsToggle(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium)
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

private fun formatFileSize(size: Long): String {
    return when {
        size >= 1024 * 1024 * 1024 -> String.format("%.2f GB", size / (1024.0 * 1024.0 * 1024.0))
        size >= 1024 * 1024 -> String.format("%.2f MB", size / (1024.0 * 1024.0))
        size >= 1024 -> String.format("%.2f KB", size / 1024.0)
        else -> "$size B"
    }
}
