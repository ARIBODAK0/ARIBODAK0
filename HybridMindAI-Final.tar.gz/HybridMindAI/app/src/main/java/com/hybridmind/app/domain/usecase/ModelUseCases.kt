package com.hybridmind.app.domain.usecase

import com.hybridmind.app.domain.model.*
import com.hybridmind.app.domain.repository.LlmRepository
import com.hybridmind.app.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

class LoadModelUseCase @Inject constructor(
    private val llmRepository: LlmRepository,
    private val settingsRepository: SettingsRepository
) {
    suspend operator fun invoke(filePath: String, parameters: ModelParameters = ModelParameters()): Result<LlmModel> {
        settingsRepository.saveLastModelPath(filePath)
        return llmRepository.loadModel(filePath, parameters)
    }
}

class UnloadModelUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    suspend operator fun invoke() {
        llmRepository.unloadModel()
    }
}

class ValidateModelFileUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    suspend operator fun invoke(filePath: String): Result<Boolean> {
        return llmRepository.validateModelFile(filePath)
    }
}

class GetModelInfoUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    suspend operator fun invoke(filePath: String): Result<LlmModel> {
        return llmRepository.getModelInfo(filePath)
    }
}

class SetInferenceBackendUseCase @Inject constructor(
    private val llmRepository: LlmRepository,
    private val settingsRepository: SettingsRepository
) {
    suspend operator fun invoke(backend: InferenceBackend) {
        llmRepository.setBackend(backend)
        settingsRepository.updateBackend(backend)
    }
}

class GetModelLoadingStateUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    operator fun invoke(): StateFlow<ModelLoadingState> {
        return llmRepository.loadingState
    }
}

class IsModelLoadedUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    operator fun invoke(): StateFlow<Boolean> {
        return llmRepository.isModelLoaded
    }
}

class GetCurrentModelUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    operator fun invoke(): StateFlow<LlmModel?> {
        return llmRepository.currentModel
    }
}

class StopGenerationUseCase @Inject constructor(
    private val llmRepository: LlmRepository
) {
    operator fun invoke() {
        llmRepository.stopGeneration()
    }
}
