package com.hybridmind.app.domain.model

enum class QuantizationType {
    Q4_0, Q4_1, Q5_0, Q5_1, Q8_0, F16, F32, UNKNOWN
}

enum class InferenceBackend {
    CPU, NNAPI, VULKAN, OPENCL
}

data class ModelParameters(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.1f,
    val maxTokens: Int = 2048,
    val contextSize: Int = 4096,
    val batchSize: Int = 512,
    val threads: Int = -1,
    val useGpu: Boolean = true,
    val gpuLayers: Int = 0
)

data class LlmModel(
    val id: String,
    val name: String,
    val filePath: String,
    val fileSize: Long,
    val quantization: QuantizationType,
    val contextLength: Int = 4096,
    val isLoaded: Boolean = false,
    val parameters: ModelParameters = ModelParameters()
)

sealed class ModelLoadingState {
    object Idle : ModelLoadingState()
    object Validating : ModelLoadingState()
    data class Loading(val progress: Int) : ModelLoadingState()
    data class Success(val model: LlmModel) : ModelLoadingState()
    data class Error(val message: String, val type: ErrorType) : ModelLoadingState()
}

enum class ErrorType {
    FILE_NOT_FOUND, INVALID_MAGIC_NUMBER, OUT_OF_MEMORY,
    UNSUPPORTED_FORMAT, CORRUPT_FILE, UNKNOWN
}
