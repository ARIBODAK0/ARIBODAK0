package com.hybridmind.app.data.remote.model

import com.google.gson.annotations.SerializedName

/**
 * DuckDuckGo Instant Answer API response
 */
data class DuckDuckGoResponse(
    @SerializedName("Abstract")
    val abstract: String? = null,
    @SerializedName("AbstractText")
    val abstractText: String? = null,
    @SerializedName("AbstractSource")
    val abstractSource: String? = null,
    @SerializedName("AbstractURL")
    val abstractURL: String? = null,
    @SerializedName("Image")
    val image: String? = null,
    @SerializedName("Heading")
    val heading: String? = null,
    @SerializedName("Answer")
    val answer: String? = null,
    @SerializedName("AnswerType")
    val answerType: String? = null,
    @SerializedName("Definition")
    val definition: String? = null,
    @SerializedName("DefinitionSource")
    val definitionSource: String? = null,
    @SerializedName("DefinitionURL")
    val definitionURL: String? = null,
    @SerializedName("RelatedTopics")
    val relatedTopics: List<RelatedTopic>? = null,
    @SerializedName("Results")
    val results: List<SearchResult>? = null,
    @SerializedName("Type")
    val type: String? = null,
    @SerializedName("Redirect")
    val redirect: String? = null
)

data class RelatedTopic(
    @SerializedName("FirstURL")
    val firstURL: String? = null,
    @SerializedName("Icon")
    val icon: Icon? = null,
    @SerializedName("Result")
    val result: String? = null,
    @SerializedName("Text")
    val text: String? = null
)

data class Icon(
    @SerializedName("URL")
    val url: String? = null,
    @SerializedName("Height")
    val height: String? = null,
    @SerializedName("Width")
    val width: String? = null
)

data class SearchResult(
    @SerializedName("FirstURL")
    val firstURL: String? = null,
    @SerializedName("Icon")
    val icon: Icon? = null,
    @SerializedName("Result")
    val result: String? = null,
    @SerializedName("Text")
    val text: String? = null
)
