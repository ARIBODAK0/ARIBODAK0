package com.hybridmind.app.domain.usecase

import com.hybridmind.app.domain.model.ChatMessage
import com.hybridmind.app.domain.model.MessageRole
import com.hybridmind.app.domain.model.SearchResult
import com.hybridmind.app.domain.model.needsRealtimeInfo
import com.hybridmind.app.domain.repository.ChatRepository
import com.hybridmind.app.domain.repository.LlmRepository
import com.hybridmind.app.domain.repository.SettingsRepository
import com.hybridmind.app.domain.repository.WebSearchRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber
import javax.inject.Inject

/**
 * Use case for sending a message and getting AI response
 */
class SendMessageUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
    private val llmRepository: LlmRepository,
    private val webSearchRepository: WebSearchRepository,
    private val settingsRepository: SettingsRepository
) {
    operator fun invoke(
        sessionId: String,
        message: String,
        useWebSearch: Boolean? = null
    ): Flow<SendMessageState> = flow {
        emit(SendMessageState.Loading)
        
        try {
            // Save user message
            val userMessage = ChatMessage(
                sessionId = sessionId,
                role = MessageRole.USER,
                content = message
            )
            chatRepository.insertMessage(userMessage)
            
            // Get settings
            val settings = settingsRepository.getSettings()
            val shouldUseWebSearch = useWebSearch ?: settings.useWebSearch
            
            // Check if model is loaded
            if (!llmRepository.isModelLoaded.value) {
                emit(SendMessageState.Error("Model belum dimuat. Silakan pilih model di pengaturan."))
                return@flow
            }
            
            // Determine if we need web search
            var searchResults: List<SearchResult>? = null
            if (shouldUseWebSearch && message.needsRealtimeInfo()) {
                emit(SendMessageState.Searching)
                searchResults = webSearchRepository.search(message).getOrElse { emptyList() }
            }
            
            // Get conversation history for context
            val history = chatRepository.getRecentMessagesForContext(sessionId, 20)
            
            // Build messages for LLM
            val messages = buildList {
                // Add system prompt
                val systemPrompt = buildSystemPrompt(settings.systemPrompt, searchResults)
                
                // Add history (excluding current user message which we already saved)
                history.filter { it.role != MessageRole.SYSTEM }.forEach { msg ->
                    add(msg.role.name.lowercase() to msg.content)
                }
            }
            
            // Generate response with streaming
            val responseBuilder = StringBuilder()
            val assistantMessage = ChatMessage(
                sessionId = sessionId,
                role = MessageRole.ASSISTANT,
                content = "",
                isStreaming = true,
                searchResults = searchResults
            )
            
            // Insert placeholder message
            chatRepository.insertMessage(assistantMessage)
            
            val result = llmRepository.generateChatCompletion(
                messages = messages,
                systemPrompt = buildSystemPrompt(settings.systemPrompt, searchResults),
                parameters = null,
                onToken = { token ->
                    responseBuilder.append(token)
                    // Emit streaming update
                    emit(SendMessageState.Streaming(responseBuilder.toString(), searchResults))
                }
            )
            
            result.fold(
                onSuccess = { fullResponse ->
                    // Update message with complete response
                    val finalMessage = assistantMessage.copy(
                        content = fullResponse,
                        isStreaming = false,
                        searchResults = searchResults
                    )
                    chatRepository.updateMessage(finalMessage)
                    emit(SendMessageState.Success(fullResponse, searchResults))
                },
                onFailure = { error ->
                    val errorMessage = error.message ?: "Unknown error"
                    val errorMsg = assistantMessage.copy(
                        content = "Maaf, terjadi kesalahan: $errorMessage",
                        isStreaming = false,
                        error = errorMessage
                    )
                    chatRepository.updateMessage(errorMsg)
                    emit(SendMessageState.Error(errorMessage))
                }
            )
            
        } catch (e: Exception) {
            Timber.e(e, "Error in SendMessageUseCase")
            emit(SendMessageState.Error(e.message ?: "Unknown error"))
        }
    }
    
    private fun buildSystemPrompt(basePrompt: String, searchResults: List<SearchResult>?): String {
        return if (searchResults != null && searchResults.isNotEmpty()) {
            val searchContext = searchResults.joinToString("\n") { 
                "[${it.source}] ${it.title}: ${it.snippet}" 
            }
            "$basePrompt\n\nBerikut informasi terkini dari web:\n$searchContext\n\n" +
            "Gunakan informasi di atas untuk menjawab pertanyaan pengguna. " +
            "Jika informasi tidak cukup, katakan saja Anda tidak tahu."
        } else {
            basePrompt
        }
    }
}

sealed class SendMessageState {
    data object Loading : SendMessageState()
    data object Searching : SendMessageState()
    data class Streaming(val partialResponse: String, val searchResults: List<SearchResult>?) : SendMessageState()
    data class Success(val response: String, val searchResults: List<SearchResult>?) : SendMessageState()
    data class Error(val message: String) : SendMessageState()
}
