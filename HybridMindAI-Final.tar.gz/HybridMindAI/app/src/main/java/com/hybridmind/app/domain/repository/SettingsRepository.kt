package com.hybridmind.app.domain.repository

import com.hybridmind.app.domain.model.AIPersonality
import com.hybridmind.app.domain.model.AppSettings
import com.hybridmind.app.domain.model.InferenceBackend
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun getSettings(): AppSettings
    suspend fun updateSystemPrompt(prompt: String)
    suspend fun updatePersonality(personality: AIPersonality)
    suspend fun updateBackend(backend: InferenceBackend)
    suspend fun setWebSearchEnabled(enabled: Boolean)
    suspend fun setAutoSpeak(enabled: Boolean)
    suspend fun setSaveHistory(enabled: Boolean)
    suspend fun setContextLimit(limit: Int)
    suspend fun setAutoSummarize(enabled: Boolean)
    suspend fun setBatterySaverThreshold(threshold: Int)
    suspend fun saveLastModelPath(path: String)
    suspend fun getLastModelPath(): String?
    suspend fun clearSettings()
}
