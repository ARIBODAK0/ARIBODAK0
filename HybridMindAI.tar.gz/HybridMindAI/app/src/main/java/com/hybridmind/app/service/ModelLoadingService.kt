package com.hybridmind.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hybridmind.app.MainActivity
import com.hybridmind.app.R
import dagger.hilt.android.AndroidEntryPoint

/**
 * Foreground service for model loading operations
 * Keeps the process alive during long-running model loads
 */
@AndroidEntryPoint
class ModelLoadingService : Service() {

    private val binder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getService(): ModelLoadingService = this@ModelLoadingService
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification("Memuat model AI…")
        startForeground(NOTIFICATION_ID, notification)
        return START_NOT_STICKY
    }

    fun updateProgress(progress: Int, message: String) {
        val notification = createNotification(message, progress)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    fun completeLoading(success: Boolean) {
        val message = if (success) "Model berhasil dimuat" else "Gagal memuat model"
        val notification = createNotification(message, isComplete = true)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Model Loading",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifikasi untuk proses loading model AI"
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(
        message: String,
        progress: Int = 0,
        isComplete: Boolean = false
    ): android.app.Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("HybridMind AI")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(!isComplete)
            .setProgress(100, progress, progress == 0)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "model_loading_channel"
        private const val NOTIFICATION_ID = 1
    }
}
