package com.hybridmind.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.hybridmind.app.domain.model.AIPersonality
import com.hybridmind.app.domain.model.AppSettings
import com.hybridmind.app.domain.model.DEFAULT_SYSTEM_PROMPT
import com.hybridmind.app.domain.model.InferenceBackend
import com.hybridmind.app.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hybridmind_settings")

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SettingsRepository {

    private val dataStore = context.dataStore

    // Preference keys
    private object PreferencesKeys {
        val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val PERSONALITY = stringPreferencesKey("personality")
        val BACKEND = stringPreferencesKey("backend")
        val USE_WEB_SEARCH = booleanPreferencesKey("use_web_search")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val SAVE_HISTORY = booleanPreferencesKey("save_history")
        val CONTEXT_LIMIT = intPreferencesKey("context_limit")
        val AUTO_SUMMARIZE = booleanPreferencesKey("auto_summarize")
        val BATTERY_SAVER_THRESHOLD = intPreferencesKey("battery_saver_threshold")
        val LANGUAGE = stringPreferencesKey("language")
        val LAST_MODEL_PATH = stringPreferencesKey("last_model_path")
    }

    override val settings: Flow<AppSettings> = dataStore.data
        .map { preferences ->
            AppSettings(
                systemPrompt = preferences[PreferencesKeys.SYSTEM_PROMPT] ?: DEFAULT_SYSTEM_PROMPT,
                personality = preferences[PreferencesKeys.PERSONALITY]?.let {
                    AIPersonality.valueOf(it)
                } ?: AIPersonality.FRIENDLY,
                backend = preferences[PreferencesKeys.BACKEND]?.let {
                    InferenceBackend.valueOf(it)
                } ?: InferenceBackend.CPU,
                useWebSearch = preferences[PreferencesKeys.USE_WEB_SEARCH] ?: false,
                autoSpeak = preferences[PreferencesKeys.AUTO_SPEAK] ?: false,
                saveHistory = preferences[PreferencesKeys.SAVE_HISTORY] ?: true,
                contextLimit = preferences[PreferencesKeys.CONTEXT_LIMIT] ?: 4096,
                autoSummarize = preferences[PreferencesKeys.AUTO_SUMMARIZE] ?: true,
                batterySaverThreshold = preferences[PreferencesKeys.BATTERY_SAVER_THRESHOLD] ?: 15,
                language = preferences[PreferencesKeys.LANGUAGE] ?: "id"
            )
        }

    override suspend fun getSettings(): AppSettings {
        return settings.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it } as AppSettings
        // Simplified - in real implementation use first() or similar
        return AppSettings() // Placeholder - use flow first() in actual implementation
    }

    override suspend fun updateSystemPrompt(prompt: String) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.SYSTEM_PROMPT] = prompt
        }
    }

    override suspend fun updatePersonality(personality: AIPersonality) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.PERSONALITY] = personality.name
        }
    }

    override suspend fun updateBackend(backend: InferenceBackend) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.BACKEND] = backend.name
        }
    }

    override suspend fun setWebSearchEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.USE_WEB_SEARCH] = enabled
        }
    }

    override suspend fun setAutoSpeak(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.AUTO_SPEAK] = enabled
        }
    }

    override suspend fun setSaveHistory(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.SAVE_HISTORY] = enabled
        }
    }

    override suspend fun setContextLimit(limit: Int) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.CONTEXT_LIMIT] = limit
        }
    }

    override suspend fun setAutoSummarize(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.AUTO_SUMMARIZE] = enabled
        }
    }

    override suspend fun setBatterySaverThreshold(threshold: Int) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.BATTERY_SAVER_THRESHOLD] = threshold
        }
    }

    override suspend fun saveLastModelPath(path: String) {
        dataStore.edit { preferences ->
            preferences[PreferencesKeys.LAST_MODEL_PATH] = path
        }
    }

    override suspend fun getLastModelPath(): String? {
        return dataStore.data.map { it[PreferencesKeys.LAST_MODEL_PATH] }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it }.map { it } as? String
    }

    override suspend fun clearSettings() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
