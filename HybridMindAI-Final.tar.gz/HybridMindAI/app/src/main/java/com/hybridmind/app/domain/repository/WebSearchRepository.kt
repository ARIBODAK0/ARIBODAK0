package com.hybridmind.app.domain.repository

import com.hybridmind.app.domain.model.SearchResult

interface WebSearchRepository {
    suspend fun search(query: String, maxResults: Int = 5): Result<List<SearchResult>>
    fun needsRealtimeInfo(query: String): Boolean
    suspend fun summarizeResults(results: List<SearchResult>, query: String): String
}

val REALTIME_KEYWORDS = setOf(
    "berita", "news", "terbaru", "latest", "hari ini", "today",
    "cuaca", "weather", "harga", "price", "saham", "stock",
    "jadwal", "schedule", "skor", "score", "hasil", "result",
    "kurs", "exchange rate", "bitcoin", "crypto",
    "2024", "2025", "2026", "sekarang", "now"
)

fun String.needsRealtimeInfo(): Boolean {
    val lowercase = this.lowercase()
    return REALTIME_KEYWORDS.any { keyword -> lowercase.contains(keyword) }
}
