package com.hybridmind.app.domain.model

enum class AIPersonality(val displayName: String, val prompt: String) {
    FRIENDLY("Ramah", "Anda adalah asisten AI yang ramah dan hangat."),
    CODER("Programmer", "Anda adalah asisten AI yang ahli dalam pemrograman."),
    WRITER("Penulis", "Anda adalah asisten AI yang ahli dalam menulis."),
    STRICT("Formal", "Anda adalah asisten AI yang profesional dan formal.")
}

data class AppSettings(
    val systemPrompt: String = "Anda adalah HybridMind AI, asisten yang membantu.",
    val personality: AIPersonality = AIPersonality.FRIENDLY,
    val backend: InferenceBackend = InferenceBackend.CPU,
    val useWebSearch: Boolean = false,
    val autoSpeak: Boolean = false,
    val saveHistory: Boolean = true,
    val contextLimit: Int = 4096,
    val autoSummarize: Boolean = true,
    val batterySaverThreshold: Int = 15,
    val language: String = "id"
)
