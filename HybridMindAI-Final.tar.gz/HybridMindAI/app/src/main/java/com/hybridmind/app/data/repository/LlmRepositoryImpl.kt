package com.hybridmind.app.data.repository

import com.hybridmind.app.domain.model.*
import com.hybridmind.app.domain.repository.LlmRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import timber.log.Timber
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LlmRepositoryImpl @Inject constructor() : LlmRepository {

    private val _loadingState = MutableStateFlow<ModelLoadingState>(ModelLoadingState.Idle)
    override val loadingState: StateFlow<ModelLoadingState> = _loadingState.asStateFlow()

    private val _isModelLoaded = MutableStateFlow(false)
    override val isModelLoaded: StateFlow<Boolean> = _isModelLoaded.asStateFlow()

    private val _currentModel = MutableStateFlow<LlmModel?>(null)
    override val currentModel: StateFlow<LlmModel?> = _currentModel.asStateFlow()

    private var currentBackend: InferenceBackend = InferenceBackend.CPU
    private var isGenerating = false
    private val generationMutex = Mutex()

    init {
        System.loadLibrary("hybridmind_llm")
    }

    external fun nativeLoadModel(modelPath: String, params: LongArray): Boolean
    external fun nativeUnloadModel(): Boolean
    external fun nativeGenerate(prompt: String, callback: TokenCallback): String
    external fun nativeStopGeneration()
    external fun nativeIsGenerating(): Boolean
    external fun nativeGetContextSizeUsed(): Int
    external fun nativeTokenize(text: String): IntArray
    external fun nativeGetModelInfo(modelPath: String): LongArray
    external fun nativeSetBackend(backend: Int): Boolean
    external fun nativeGetMemoryUsage(): LongArray

    interface TokenCallback {
        fun onToken(token: String)
    }

    override suspend fun loadModel(filePath: String, parameters: ModelParameters): Result<LlmModel> {
        return withContext(Dispatchers.Default) {
            try {
                _loadingState.value = ModelLoadingState.Validating

                val file = File(filePath)
                if (!file.exists()) {
                    return@withContext Result.failure(Exception("Model file not found: $filePath"))
                }

                if (!validateGGUF(filePath)) {
                    return@withContext Result.failure(Exception("Invalid GGUF file format"))
                }

                _loadingState.value = ModelLoadingState.Loading(0)

                val modelInfo = getModelInfo(filePath).getOrElse {
                    return@withContext Result.failure(it)
                }

                val nativeParams = longArrayOf(
                    parameters.contextSize.toLong(),
                    parameters.batchSize.toLong(),
                    parameters.threads.toLong().coerceAtLeast(1),
                    if (parameters.useGpu) 1L else 0L,
                    parameters.gpuLayers.toLong()
                )

                val success = nativeLoadModel(filePath, nativeParams)

                if (success) {
                    _isModelLoaded.value = true
                    _currentModel.value = modelInfo.copy(isLoaded = true)
                    _loadingState.value = ModelLoadingState.Success(modelInfo.copy(isLoaded = true))
                    Result.success(modelInfo.copy(isLoaded = true))
                } else {
                    _loadingState.value = ModelLoadingState.Error("Failed to load model", ErrorType.UNKNOWN)
                    Result.failure(Exception("Native model loading failed"))
                }
            } catch (e: OutOfMemoryError) {
                _loadingState.value = ModelLoadingState.Error("Out of memory", ErrorType.OUT_OF_MEMORY)
                Result.failure(e)
            } catch (e: Exception) {
                Timber.e(e, "Error loading model")
                _loadingState.value = ModelLoadingState.Error(e.message ?: "Unknown error", ErrorType.UNKNOWN)
                Result.failure(e)
            }
        }
    }

    override suspend fun unloadModel() {
        withContext(Dispatchers.Default) {
            try {
                stopGeneration()
                nativeUnloadModel()
                _isModelLoaded.value = false
                _currentModel.value = null
                _loadingState.value = ModelLoadingState.Idle
            } catch (e: Exception) {
                Timber.e(e, "Error unloading model")
            }
        }
    }

    override suspend fun validateModelFile(filePath: String): Result<Boolean> {
        return try {
            Result.success(validateGGUF(filePath))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun generateCompletion(
        prompt: String,
        systemPrompt: String?,
        parameters: ModelParameters?,
        onToken: suspend (String) -> Unit
    ): Result<String> = withContext(Dispatchers.Default) {
        generationMutex.withLock {
            if (!_isModelLoaded.value) {
                return@withContext Result.failure(Exception("Model not loaded"))
            }

            try {
                isGenerating = true
                val fullPrompt = systemPrompt?.let { "System: $it\n\nUser: $prompt\nAssistant:" }
                    ?: "User: $prompt\nAssistant:"

                val callback = object : TokenCallback {
                    override fun onToken(token: String) {
                        launch { onToken(token) }
                    }
                }

                val result = nativeGenerate(fullPrompt, callback)
                isGenerating = false
                Result.success(result)
            } catch (e: Exception) {
                isGenerating = false
                Timber.e(e, "Generation error")
                Result.failure(e)
            }
        }
    }

    override suspend fun generateChatCompletion(
        messages: List<Pair<String, String>>,
        systemPrompt: String?,
        parameters: ModelParameters?,
        onToken: suspend (String) -> Unit
    ): Result<String> = withContext(Dispatchers.Default) {
        generationMutex.withLock {
            if (!_isModelLoaded.value) {
                return@withContext Result.failure(Exception("Model not loaded"))
            }

            try {
                isGenerating = true
                val promptBuilder = StringBuilder()

                systemPrompt?.let {
                    promptBuilder.appendLine("System: $it")
                    promptBuilder.appendLine()
                }

                messages.forEach { (role, content) ->
                    val roleLabel = when (role.lowercase()) {
                        "user" -> "User"
                        "assistant" -> "Assistant"
                        "system" -> "System"
                        else -> role.capitalize()
                    }
                    promptBuilder.appendLine("$roleLabel: $content")
                }
                promptBuilder.append("Assistant:")

                val callback = object : TokenCallback {
                    override fun onToken(token: String) {
                        launch { onToken(token) }
                    }
                }

                val result = nativeGenerate(promptBuilder.toString(), callback)
                isGenerating = false
                Result.success(result)
            } catch (e: Exception) {
                isGenerating = false
                Timber.e(e, "Chat generation error")
                Result.failure(e)
            }
        }
    }

    override fun stopGeneration() {
        nativeStopGeneration()
        isGenerating = false
    }

    override fun isGenerating(): Boolean {
        return isGenerating || nativeIsGenerating()
    }

    override suspend fun getModelInfo(filePath: String): Result<LlmModel> {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(filePath)
                if (!file.exists()) {
                    return@withContext Result.failure(Exception("File not found"))
                }

                val info = nativeGetModelInfo(filePath)
                val quantType = parseQuantizationFromFilename(file.name)

                val model = LlmModel(
                    id = filePath.hashCode().toString(),
                    name = file.nameWithoutExtension,
                    filePath = filePath,
                    fileSize = file.length(),
                    quantization = quantType,
                    contextLength = info.getOrNull(0)?.toInt() ?: 4096,
                    isLoaded = false
                )

                Result.success(model)
            } catch (e: Exception) {
                Timber.e(e, "Error getting model info")
                Result.failure(e)
            }
        }
    }

    override suspend fun setBackend(backend: InferenceBackend) {
        withContext(Dispatchers.Default) {
            val backendCode = when (backend) {
                InferenceBackend.CPU -> 0
                InferenceBackend.NNAPI -> 1
                InferenceBackend.VULKAN -> 2
                InferenceBackend.OPENCL -> 3
            }
            nativeSetBackend(backendCode)
            currentBackend = backend
        }
    }

    override fun getCurrentBackend(): InferenceBackend {
        return currentBackend
    }

    override fun getMemoryUsage(): Pair<Long, Long> {
        val usage = nativeGetMemoryUsage()
        return Pair(usage[0], usage[1])
    }

    override suspend fun tokenize(text: String): Result<Int> {
        return try {
            val tokens = nativeTokenize(text)
            Result.success(tokens.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun validateGGUF(filePath: String): Boolean {
        return try {
            RandomAccessFile(filePath, "r").use { file ->
                val buffer = ByteArray(4)
                file.read(buffer)
                val magic = ByteBuffer.wrap(buffer).order(ByteOrder.LITTLE_ENDIAN).int
                magic == 0x46554747 || magic == 0x47475546
            }
        } catch (e: Exception) {
            Timber.e(e, "Error validating GGUF file")
            false
        }
    }

    private fun parseQuantizationFromFilename(filename: String): QuantizationType {
        val lower = filename.lowercase()
        return when {
            "q4_0" in lower -> QuantizationType.Q4_0
            "q4_1" in lower -> QuantizationType.Q4_1
            "q5_0" in lower -> QuantizationType.Q5_0
            "q5_1" in lower -> QuantizationType.Q5_1
            "q8_0" in lower -> QuantizationType.Q8_0
            "f16" in lower -> QuantizationType.F16
            "f32" in lower -> QuantizationType.F32
            else -> QuantizationType.UNKNOWN
        }
    }
}
