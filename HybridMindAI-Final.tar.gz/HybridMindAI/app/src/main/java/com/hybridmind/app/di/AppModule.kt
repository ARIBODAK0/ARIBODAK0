package com.hybridmind.app.di

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.hybridmind.app.data.local.dao.ChatMessageDao
import com.hybridmind.app.data.local.dao.ChatSessionDao
import com.hybridmind.app.data.local.database.AppDatabase
import com.hybridmind.app.data.remote.api.DuckDuckGoApi
import com.hybridmind.app.data.repository.*
import com.hybridmind.app.domain.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideGson(): Gson {
        return GsonBuilder().setLenient().create()
    }

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideChatSessionDao(database: AppDatabase): ChatSessionDao {
        return database.chatSessionDao()
    }

    @Provides
    @Singleton
    fun provideChatMessageDao(database: AppDatabase): ChatMessageDao {
        return database.chatMessageDao()
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideDuckDuckGoApi(okHttpClient: OkHttpClient): DuckDuckGoApi {
        return Retrofit.Builder()
            .baseUrl(DuckDuckGoApi.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DuckDuckGoApi::class.java)
    }

    @Provides
    @Singleton
    fun provideChatRepository(
        sessionDao: ChatSessionDao,
        messageDao: ChatMessageDao,
        gson: Gson
    ): ChatRepository {
        return ChatRepositoryImpl(sessionDao, messageDao, gson)
    }

    @Provides
    @Singleton
    fun provideSettingsRepository(
        @ApplicationContext context: Context
    ): SettingsRepository {
        return SettingsRepositoryImpl(context)
    }

    @Provides
    @Singleton
    fun provideWebSearchRepository(
        duckDuckGoApi: DuckDuckGoApi
    ): WebSearchRepository {
        return WebSearchRepositoryImpl(duckDuckGoApi)
    }

    @Provides
    @Singleton
    fun provideLlmRepository(): LlmRepository {
        return LlmRepositoryImpl()
    }
}
