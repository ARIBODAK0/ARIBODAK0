package com.hybridmind.app.domain.usecase

import com.hybridmind.app.domain.model.ChatMessage
import com.hybridmind.app.domain.model.MessageRole
import com.hybridmind.app.domain.model.SearchResult
import com.hybridmind.app.domain.model.needsRealtimeInfo
import com.hybridmind.app.domain.repository.ChatRepository
import com.hybridmind.app.domain.repository.LlmRepository
import com.hybridmind.app.domain.repository.SettingsRepository
import com.hybridmind.app.domain.repository.WebSearchRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber
import javax.inject.Inject

class SendMessageUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
    private val llmRepository: LlmRepository,
    private val webSearchRepository: WebSearchRepository,
    private val settingsRepository: SettingsRepository
) {
    operator fun invoke(
        sessionId: String,
        message: String,
        useWebSearch: Boolean? = null
    ): Flow<SendMessageState> = flow {
        emit(SendMessageState.Loading)

        try {
            val userMessage = ChatMessage(
                sessionId = sessionId,
                role = MessageRole.USER,
                content = message
            )
            chatRepository.insertMessage(userMessage)

            val settings = settingsRepository.getSettings()
            val shouldUseWebSearch = useWebSearch ?: settings.useWebSearch

            if (!llmRepository.isModelLoaded.value) {
                emit(SendMessageState.Error("Model belum dimuat. Silakan pilih model di pengaturan."))
                return@flow
            }

            var searchResults: List<SearchResult>? = null
            if (shouldUseWebSearch && message.needsRealtimeInfo()) {
                emit(SendMessageState.Searching)
                searchResults = webSearchRepository.search(message).getOrElse { emptyList() }
            }

            val history = chatRepository.getRecentMessagesForContext(sessionId, 20)
            val messages = history.filter { it.role != MessageRole.SYSTEM }
                .map { it.role.name.lowercase() to it.content }

            val responseBuilder = StringBuilder()
            val assistantMessage = ChatMessage(
                sessionId = sessionId,
                role = MessageRole.ASSISTANT,
                content = "",
                isStreaming = true,
                searchResults = searchResults
            )
            chatRepository.insertMessage(assistantMessage)

            val systemPrompt = buildSystemPrompt(settings.systemPrompt, searchResults)

            val result = llmRepository.generateChatCompletion(
                messages = messages,
                systemPrompt = systemPrompt,
                parameters = null,
                onToken = { token ->
                    responseBuilder.append(token)
                    emit(SendMessageState.Streaming(responseBuilder.toString(), searchResults))
                }
            )

            result.fold(
                onSuccess = { fullResponse ->
                    val finalMessage = assistantMessage.copy(
                        content = fullResponse,
                        isStreaming = false,
                        searchResults = searchResults
                    )
                    chatRepository.updateMessage(finalMessage)
                    emit(SendMessageState.Success(fullResponse, searchResults))
                },
                onFailure = { error ->
                    val errorMessage = error.message ?: "Unknown error"
                    val errorMsg = assistantMessage.copy(
                        content = "Maaf, terjadi kesalahan: $errorMessage",
                        isStreaming = false,
                        error = errorMessage
                    )
                    chatRepository.updateMessage(errorMsg)
                    emit(SendMessageState.Error(errorMessage))
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Error in SendMessageUseCase")
            emit(SendMessageState.Error(e.message ?: "Unknown error"))
        }
    }

    private fun buildSystemPrompt(basePrompt: String, searchResults: List<SearchResult>?): String {
        return if (searchResults != null && searchResults.isNotEmpty()) {
            val searchContext = searchResults.joinToString("\n") {
                "[${it.source}] ${it.title}: ${it.snippet}"
            }
            "$basePrompt\n\nInformasi terkini:\n$searchContext"
        } else {
            basePrompt
        }
    }
}

sealed class SendMessageState {
    object Loading : SendMessageState()
    object Searching : SendMessageState()
    data class Streaming(val partialResponse: String, val searchResults: List<SearchResult>?) : SendMessageState()
    data class Success(val response: String, val searchResults: List<SearchResult>?) : SendMessageState()
    data class Error(val message: String) : SendMessageState()
}
