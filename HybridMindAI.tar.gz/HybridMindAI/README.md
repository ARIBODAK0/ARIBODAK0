# HybridMind AI

[![Android](https://img.shields.io/badge/Android-16%2B-green.svg)](https://developer.android.com)
[![Kotlin](https://img.shields.io/badge/Kotlin-1.9-blue.svg)](https://kotlinlang.org)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**HybridMind AI** adalah asisten AI privat yang berjalan 100% secara lokal di perangkat Android Anda menggunakan teknologi llama.cpp. Dengan arsitektur hybrid, aplikasi ini dapat menggabungkan kekuatan LLM lokal dengan kemampuan pencarian web untuk informasi real-time.

## Fitur Utama

### Local-First Architecture
- **100% Privat** - Semua data dan percakapan disimpan secara lokal
- **Offline Ready** - Tidak memerlukan internet untuk chat biasa
- **Enkripsi** - Database terenkripsi dengan SQLCipher

### Hybrid Engine
- **Local LLM** - Inference menggunakan llama.cpp (GGUF format)
- **Web Search** - Integrasi DuckDuckGo untuk informasi real-time
- **Smart Detection** - Otomatis deteksi kapan perlu pencarian web

### Modern UI
- **Jetpack Compose** - UI modern dengan Material Design 3
- **Glassmorphism** - Desain elegan dengan efek blur
- **Dark Mode** - Tema gelap yang nyaman di mata
- **Streaming Response** - Respons token-by-token (typewriter effect)

### Manajemen Chat
- **Session Memory** - Setiap chat memiliki konteks terisolasi
- **History** - Riwayat chat tersimpan dengan aman
- **Context Management** - Auto-truncate saat konteks penuh

### Kustomisasi
- **System Prompt** - Sesuaikan perilaku AI
- **Personality Presets** - Coder, Writer, Friendly, Strict
- **Hardware Config** - NNAPI, Vulkan, atau CPU Only

## Screenshots

| Onboarding | Chat Interface | Settings |
|------------|----------------|----------|
| Welcome & Privacy | Modern Chat UI | Full Customization |

## Persyaratan Sistem

- **Android**: 8.0 (API 26) atau lebih tinggi
- **RAM**: Minimal 4GB (disarankan 6GB+)
- **Storage**: Minimal 3GB free space untuk model
- **CPU**: ARM64 (arm64-v8a) disarankan

## Rekomendasi Model

| Model | Ukuran | Kuantasi | RAM | Deskripsi |
|-------|--------|----------|-----|-----------|
| Phi-3 Mini | ~2.3GB | Q4_0 | 4GB | Cepat & ringan |
| Gemma 2B | ~1.5GB | Q4_0 | 3GB | Sangat efisien |
| Qwen2 7B | ~4.5GB | Q4_0 | 6GB | Multibahasa kuat |
| Llama 3 8B | ~4.7GB | Q4_0 | 6GB | Performa tinggi |

## Cara Install

### 1. Download Model GGUF

1. Kunjungi [HuggingFace](https://huggingface.co/models?search=gguf)
2. Pilih model yang diinginkan (rekomendasi di atas)
3. Download file `.gguf` (versi Q4_0 atau Q4_1)
4. Simpan file di folder **Downloads** atau **Documents**

### 2. Install APK

```bash
# Install APK
cd app/build/outputs/apk/release
adb install HybridMindAI-release.apk
```

### 3. Setup Pertama

1. Buka aplikasi HybridMind AI
2. Lewati onboarding
3. Pilih file `.gguf` yang sudah didownload
4. Tunggu model dimuat
5. Mulai chat!

## Build dari Source

### Prerequisites

- Android Studio Hedgehog (2023.1.1) atau lebih baru
- JDK 17
- Android SDK 34
- NDK 25.2.9519653
- CMake 3.22.1

### Clone Repository

```bash
git clone https://github.com/yourusername/HybridMindAI.git
cd HybridMindAI
```

### Build Project

```bash
# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease
```

### Integrasi llama.cpp

Untuk integrasi penuh dengan llama.cpp:

1. Clone llama.cpp sebagai submodule:
```bash
git submodule add https://github.com/ggerganov/llama.git app/src/main/cpp/llama
```

2. Update `CMakeLists.txt` untuk link dengan llama.cpp

3. Rebuild project

## Arsitektur

```
app/
├── data/
│   ├── local/          # Room Database + SQLCipher
│   ├── remote/         # API (DuckDuckGo, etc)
│   └── repository/     # Repository implementations
├── domain/
│   ├── model/          # Domain models
│   ├── repository/     # Repository interfaces
│   └── usecase/        # Use cases
├── di/                 # Hilt DI modules
├── ui/
│   ├── screens/        # Compose screens
│   ├── theme/          # Material Theme
│   └── viewmodel/      # ViewModels
└── cpp/                # JNI native code
```

## Teknologi

- **Kotlin** - 100% Kotlin
- **Jetpack Compose** - Modern UI toolkit
- **Hilt** - Dependency Injection
- **Room** - Local database
- **SQLCipher** - Database encryption
- **Retrofit** - Networking
- **llama.cpp** - Local LLM inference
- **Coroutines + Flow** - Async programming

## Permissions

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
```

**Catatan**: Permission INTERNET hanya digunakan untuk web search. Tidak ada data yang dikirim ke server eksternal.

## Keamanan & Privasi

- ✅ Semua data disimpan secara lokal
- ✅ Database terenkripsi dengan SQLCipher
- ✅ Tidak ada analytics atau tracking
- ✅ Tidak ada data yang dikirim ke cloud
- ✅ Model berjalan 100% di device

## Troubleshooting

### Model gagal dimuat

1. Pastikan file adalah format `.gguf` yang valid
2. Cek magic number file (harus `GGUF`)
3. Pastikan RAM cukup untuk model
4. Coba model yang lebih kecil (Gemma 2B)

### Out of Memory

1. Tutup aplikasi lain
2. Gunakan model dengan kuantasi lebih rendah (Q4_0)
3. Kurangi context size di settings
4. Restart device

### Inference lambat

1. Aktifkan NNAPI di settings (jika device mendukung)
2. Gunakan model yang lebih kecil
3. Pastikan device tidak panas (thermal throttling)

## Roadmap

- [x] Local LLM inference
- [x] Web search integration
- [x] Chat history with encryption
- [x] Multiple sessions
- [ ] Voice input (Whisper.cpp)
- [ ] Export chat (PDF/Markdown)
- [ ] RAG (Retrieval Augmented Generation)
- [ ] Plugin system
- [ ] Multi-language support

## Contributing

Kontribusi sangat diterima! Silakan:

1. Fork repository
2. Buat branch baru (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## License

```
MIT License

Copyright (c) 2024 HybridMind AI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Acknowledgments

- [llama.cpp](https://github.com/ggerganov/llama.cpp) - by Georgi Gerganov
- [HuggingFace](https://huggingface.co) - Model hosting
- [Jetpack Compose](https://developer.android.com/jetpack/compose) - UI framework

## Kontak

- Email: support@hybridmind.ai
- GitHub: [github.com/yourusername/HybridMindAI](https://github.com/yourusername/HybridMindAI)
- Discord: [discord.gg/hybridmind](https://discord.gg/hybridmind)

---

**Made with ❤️ in Indonesia**
