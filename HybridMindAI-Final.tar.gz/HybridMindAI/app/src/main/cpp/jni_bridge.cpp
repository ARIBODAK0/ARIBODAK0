#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>

#define LOG_TAG "HybridMindJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static bool g_is_generating = false;

struct TokenCallback {
    JNIEnv* env;
    jobject callback;
    jmethodID onTokenMethod;
};

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeLoadModel(JNIEnv* env, jobject thiz, jstring modelPath, jlongArray params) {
    const char* path = env->GetStringUTFChars(modelPath, nullptr);
    LOGI("Loading model from: %s", path);

    jlong* nativeParams = env->GetLongArrayElements(params, nullptr);
    int contextSize = static_cast<int>(nativeParams[0]);
    int batchSize = static_cast<int>(nativeParams[1]);
    int threads = static_cast<int>(nativeParams[2]);
    bool useGpu = nativeParams[3] != 0;
    int gpuLayers = static_cast<int>(nativeParams[4]);

    LOGI("Params: ctx=%d, batch=%d, threads=%d, gpu=%d, gpu_layers=%d", contextSize, batchSize, threads, useGpu, gpuLayers);

    bool success = true;

    env->ReleaseLongArrayElements(params, nativeParams, JNI_ABORT);
    env->ReleaseStringUTFChars(modelPath, path);

    return success ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeUnloadModel(JNIEnv* env, jobject thiz) {
    LOGI("Unloading model");
    g_is_generating = false;
    return JNI_TRUE;
}

JNIEXPORT jstring JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeGenerate(JNIEnv* env, jobject thiz, jstring prompt, jobject callback) {
    const char* promptStr = env->GetStringUTFChars(prompt, nullptr);
    LOGI("Generating for prompt length: %zu", strlen(promptStr));

    g_is_generating = true;

    TokenCallback tokenCallback;
    if (callback != nullptr) {
        tokenCallback.env = env;
        tokenCallback.callback = env->NewGlobalRef(callback);
        jclass callbackClass = env->GetObjectClass(callback);
        tokenCallback.onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;)V");
    }

    std::string result = "Halo! Saya adalah HybridMind AI, asisten pintar yang berjalan lokal di perangkat Anda.\n\n";
    result += "Prompt: ";
    result += promptStr;

    if (callback != nullptr) {
        for (size_t i = 0; i < result.length() && g_is_generating; i += 5) {
            std::string token = result.substr(i, 5);
            jstring jToken = env->NewStringUTF(token.c_str());
            env->CallVoidMethod(tokenCallback.callback, tokenCallback.onTokenMethod, jToken);
            env->DeleteLocalRef(jToken);
        }
    }

    g_is_generating = false;

    if (callback != nullptr) {
        env->DeleteGlobalRef(tokenCallback.callback);
    }

    env->ReleaseStringUTFChars(prompt, promptStr);
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT void JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeStopGeneration(JNIEnv* env, jobject thiz) {
    LOGI("Stopping generation");
    g_is_generating = false;
}

JNIEXPORT jboolean JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeIsGenerating(JNIEnv* env, jobject thiz) {
    return g_is_generating ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeGetContextSizeUsed(JNIEnv* env, jobject thiz) {
    return 0;
}

JNIEXPORT jintArray JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeTokenize(JNIEnv* env, jobject thiz, jstring text) {
    jintArray result = env->NewIntArray(0);
    return result;
}

JNIEXPORT jlongArray JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeGetModelInfo(JNIEnv* env, jobject thiz, jstring modelPath) {
    jlong info[] = { 4096, 32, 4096, 0 };
    jlongArray result = env->NewLongArray(4);
    env->SetLongArrayRegion(result, 0, 4, info);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeSetBackend(JNIEnv* env, jobject thiz, jint backend) {
    LOGI("Setting backend to: %d", backend);
    return JNI_TRUE;
}

JNIEXPORT jlongArray JNICALL
Java_com_hybridmind_app_data_repository_LlmRepositoryImpl_nativeGetMemoryUsage(JNIEnv* env, jobject thiz) {
    jlong usage[] = { 0, 0 };
    jlongArray result = env->NewLongArray(2);
    env->SetLongArrayRegion(result, 0, 2, usage);
    return result;
}

}
