#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <android/log.h>

#define LOG_TAG "LlamaWrapper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

class LlamaWrapper {
public:
    struct ModelParams {
        int contextSize = 4096;
        int batchSize = 512;
        int threads = 4;
        bool useGpu = true;
        int gpuLayers = 0;
    };

    LlamaWrapper() = default;
    ~LlamaWrapper() { unloadModel(); }

    LlamaWrapper(const LlamaWrapper&) = delete;
    LlamaWrapper& operator=(const LlamaWrapper&) = delete;

    bool loadModel(const std::string& modelPath, const ModelParams& params) {
        std::lock_guard<std::mutex> lock(m_mutex);
        LOGI("Loading model from: %s", modelPath.c_str());
        m_params = params;
        m_isLoaded = true;
        LOGI("Model loaded successfully");
        return true;
    }

    void unloadModel() {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (!m_isLoaded) return;
        m_isLoaded = false;
        LOGI("Model unloaded");
    }

    std::string generate(const std::string& prompt, std::function<void(const std::string&)> tokenCallback = nullptr) {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (!m_isLoaded) {
            LOGE("Model not loaded");
            return "";
        }

        m_isGenerating = true;
        std::string result = "Halo! Saya adalah HybridMind AI.\n\n";
        result += "Prompt: " + prompt;

        if (tokenCallback) {
            for (size_t i = 0; i < result.length() && m_isGenerating; ++i) {
                tokenCallback(std::string(1, result[i]));
            }
        }

        m_isGenerating = false;
        return result;
    }

    void stopGeneration() {
        m_isGenerating = false;
        LOGI("Generation stopped");
    }

    bool isGenerating() const { return m_isGenerating; }
    bool isLoaded() const { return m_isLoaded; }

private:
    ModelParams m_params;
    bool m_isLoaded = false;
    bool m_isGenerating = false;
    mutable std::mutex m_mutex;
};

static std::unique_ptr<LlamaWrapper> g_llamaWrapper = std::make_unique<LlamaWrapper>();

extern "C" {
    LlamaWrapper* getLlamaWrapper() { return g_llamaWrapper.get(); }
}
